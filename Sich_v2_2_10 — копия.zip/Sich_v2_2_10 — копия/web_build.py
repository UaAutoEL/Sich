import os
import shutil
import subprocess
from datetime import datetime
Import("env")

def build_web_ui(*args, **kwargs):
    print("\n[Sich-Build] --- ЗАПУСК ЗАПІКАННЯ ІНТЕРФЕЙСУ ---")
    
    project_dir = env.get("PROJECT_DIR")
    
    # Шукаємо package.json (корінь або wled00/data)
    root_package = os.path.join(project_dir, "package.json")
    standard_package = os.path.join(project_dir, "wled00", "data", "package.json")

    work_dir = None
    if os.path.exists(root_package):
        work_dir = project_dir
    elif os.path.exists(standard_package):
        work_dir = os.path.join(project_dir, "wled00", "data")
    else:
        print(f"[Sich-Build] ⚠️ package.json не знайдено. Пропускаю запікання.")
        return 

    try:
        # shell=True обов'язково для Windows
        subprocess.run(["npm", "run", "build"], cwd=work_dir, shell=True, check=True)
        print("[Sich-Build] 🎉 ВЕБ-ІНТЕРФЕЙС ЗАПЕЧЕНИЙ!\n")
    except Exception as e:
        print(f"[Sich-Build] ❌ ПОМИЛКА NPM: {e}")

def copy_and_rename_firmware(source, target, env):
    # Отримуємо версію
    fw_version = env.GetProjectOption("custom_release_version", "v.unknown")
    env_name = env.get("PIOENV")
    
    release_dir = os.path.join(env.get("PROJECT_DIR"), "RELEASES")
    if not os.path.exists(release_dir):
        os.makedirs(release_dir)

    date_str = datetime.now().strftime("%d-%m-%H%M")
    new_file_name = f"Sich_{env_name}_{fw_version}_{date_str}.bin"
    
    # ОСЬ ТУТ БУЛА ПРОБЛЕМА. Тепер ми беремо правильний шлях.
    # target[0] - це шлях до скомпільованого .bin файлу
    source_bin = str(target[0])
    destination_bin = os.path.join(release_dir, new_file_name)

    import time
    time.sleep(0.5)

    if os.path.exists(source_bin):
        try:
            shutil.copy(source_bin, destination_bin)
            print(f"\n[Sich-Release] ✅ УСПІХ! Файл скопійовано:")
            print(f"[Sich-Release] 📂 {new_file_name}")
            print(f"[Sich-Release] Шлях: {release_dir}\n")
        except Exception as e:
             print(f"[Sich-Release] ❌ Помилка копіювання: {e}")
    else:
        # Тепер скрипт скаже, якщо не знайде файл
        print(f"\n[Sich-Release] ❌ ПОМИЛКА: Не знайдено файл-джерело: {source_bin}")

# Реєструємо дії
env.AddPreAction("buildprog", build_web_ui)

# ВАЖЛИВО: Змінив прив'язку назад до .bin файлу, щоб target[0] був правильним
env.AddPostAction("$BUILD_DIR/${PROGNAME}.bin", copy_and_rename_firmware)