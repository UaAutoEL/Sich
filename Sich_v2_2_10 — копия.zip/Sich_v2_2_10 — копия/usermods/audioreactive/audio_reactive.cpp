#include "wled.h"

#ifdef ARDUINO_ARCH_ESP32

#include <driver/i2s.h>
#include <driver/adc.h>

#ifdef WLED_ENABLE_DMX
  #error Цей аудіо-реактивний usermod несумісний з DMX Out.
#endif

#endif

#if defined(ARDUINO_ARCH_ESP32) && (defined(WLED_DEBUG) || defined(SR_DEBUG))
#include <esp_timer.h>
#endif

/*
 * Usermods дозволяють легше додавати власний функціонал до WLED
 * Дивись: https://github.com/wled-dev/WLED/wiki/Add-own-functionality
 * * Це аудіо-реактивний usermod версії 2 (v2).
 * ....
 */

#if !defined(FFTTASK_PRIORITY)
#define FFTTASK_PRIORITY 1 // стандарт: пріоритет looptask
//#define FFTTASK_PRIORITY 2 // вище looptask, нижче asyc_tcp
//#define FFTTASK_PRIORITY 4 // вище asyc_tcp
#endif

// Закоментуйте/Розкоментуйте для перемикання налагодження через USB серійний порт
// #define MIC_LOGGER                   // Налагодження семплювання мікрофона та вхідного звуку (serial plotter)
// #define FFT_SAMPLING_LOG             // Налагодження результатів FFT (швидке перетворення Фур'є)
// #define SR_DEBUG                     // загальні повідомлення налагодження SR

#ifdef SR_DEBUG
  #define DEBUGSR_PRINT(x) DEBUGOUT.print(x)
  #define DEBUGSR_PRINTLN(x) DEBUGOUT.println(x)
  #define DEBUGSR_PRINTF(x...) DEBUGOUT.printf(x)
#else
  #define DEBUGSR_PRINT(x)
  #define DEBUGSR_PRINTLN(x)
  #define DEBUGSR_PRINTF(x...)
#endif

#if defined(MIC_LOGGER) || defined(FFT_SAMPLING_LOG)
  #define PLOT_PRINT(x) DEBUGOUT.print(x)
  #define PLOT_PRINTLN(x) DEBUGOUT.println(x)
  #define PLOT_PRINTF(x...) DEBUGOUT.printf(x)
#else
  #define PLOT_PRINT(x)
  #define PLOT_PRINTLN(x)
  #define PLOT_PRINTF(x...)
#endif

#define MAX_PALETTES 3

static volatile bool disableSoundProcessing = false;      // якщо true, обробка звуку (FFT, фільтри, AGC) буде призупинена. "volatile", оскільки спільна між завданнями.
static uint8_t audioSyncEnabled = 0;          // бітове поле: біт 0 - відправка, біт 1 - отримання (значення конфігурації)
static bool udpSyncConnected = false;         // Статус з'єднання UDP -> true, якщо підключено до multicast групи

#define NUM_GEQ_CHANNELS 16                                           // кількість частотних каналів. Не змінювати !!

// змінні аудіореактивності
#ifdef ARDUINO_ARCH_ESP32
    #ifndef SR_AGC // Режим автоматичного регулювання підсилення (АРП)
    #define SR_AGC 2 // режим за замовчуванням = вимкнено
    #endif
static float    micDataReal = 0.0f;             // Дані MicIn з повною роздільною здатністю 24 біт - найнижчі 8 біт після коми
static float    multAgc = 1.0f;                 // семпл * multAgc = sampleAgc. Наш множник АРП (AGC)
static float    sampleAvg = 0.0f;               // Згладжений середній семпл - sampleAvg < 1 означає "тиша" (простий шумоподавлювач/noise gate)
static float    sampleAgc = 0.0f;               // Згладжений семпл АРП (AGC)
static uint8_t  soundAgc = SR_AGC;              // Автоматичне регулювання підсилення: 0 - вимк, 1 - нормальний, 2 - яскравий, 3 - лінивий (значення конфігурації)
#endif
//static float    volumeSmth = 0.0f;              // або sampleAvg, або sampleAgc залежно від soundAgc; згладжений семпл
static float FFT_MajorPeak = 1.0f;              // FFT: найсильніша (пікова) частота
static float FFT_Magnitude = 0.0f;              // FFT: гучність (величини) пікової частоти
static bool samplePeak = false;      // Логічний прапор для піку - використовується в ефектах. Процедура відповіді може скинути цей прапор. Автоскидання після strip.getFrameTime()
static bool udpSamplePeak = false;   // Логічний прапор для піку. Встановлюється одночасно з samplePeak, але скидається через transmitAudioData
static unsigned long timeOfPeak = 0; // час виявлення останнього піку семплу.
static uint8_t fftResult[NUM_GEQ_CHANNELS]= {0};// Наша таблиця результатів розрахованих частотних каналів для використання ефектами

// TODO: ймовірно, краще не використовувати вузлами прийому (receive nodes)
//static float agcSensitivity = 128;            // Оцінка чутливості АРП, на основі підсилення АРП (multAgc). розраховується через getSensitivity(). діапазон 0..255

// параметри, що налаштовуються користувачем для limitSoundDynamics()
#ifdef UM_AUDIOREACTIVE_DYNAMICS_LIMITER_OFF
static bool limiterOn = false;                 // bool: увімкнути / вимкнути обмежувач динаміки
#else
static bool limiterOn = true;
#endif
static uint16_t attackTime =  80;             // int: час атаки в мілісекундах. За замовчуванням 0.08 сек
static uint16_t decayTime = 1400;             // int: час спаду в мілісекундах.  За замовчуванням 1.40 сек

// виявлення піків
#ifdef ARDUINO_ARCH_ESP32
static void detectSamplePeak(void);  // функція виявлення піків (потребує масштабованих результатів FFT у vReal[]) - не використовується для режиму 8266 тільки-прийом
#endif
static void autoResetPeak(void);     // функція автоскидання піку
static uint8_t maxVol = 31;          // (було 10) Розумне значення для постійної гучності для 'детектора піків', оскільки він не завжди спрацьовуватиме (застаріло)
static uint8_t binNum = 8;           // Використовується для вибору біна (кошика) для виявлення біта на основі FFT (застаріло)

#ifdef ARDUINO_ARCH_ESP32

// використання класу аудіоджерела (специфічно для ESP32)
#include "audio_source.h"
constexpr i2s_port_t I2S_PORT = I2S_NUM_0;       // I2S порт для використання (не змінювати !)
constexpr int BLOCK_SIZE = 128;                  // Розмір буфера I2S (семпли)

// глобальні змінні
static uint8_t inputLevel = 128;              // значення повзунка UI
#ifndef SR_SQUELCH
  uint8_t soundSquelch = 2;                  // значення шумоподавлення (squelch) для процедур реакції на гучність (конфігурація)
#else
  uint8_t soundSquelch = SR_SQUELCH;          // значення шумоподавлення
#endif
#ifndef SR_GAIN
  uint8_t sampleGain = 100;                    // підсилення семплу (конфігурація)
#else
  uint8_t sampleGain = SR_GAIN;               // підсилення семплу
#endif
// параметри налаштування користувача для масштабування FFTResult
static uint8_t FFTScalingMode = 3;            // 0 немає; 1 оптимізований логарифмічний; 2 оптимізований лінійний; 3 оптимізований квадратний корінь

// 
// Пресети АРП (AGC)
//  Примітка: в C++, "const" передбачає "static" - немає потреби явно оголошувати все як "static const"
// 
#define AGC_NUM_PRESETS 3 // Пресети АРП:       нормальний,   яскравий,    лінивий
const double agcSampleDecay[AGC_NUM_PRESETS]  = { 0.9994f, 0.9985f, 0.9997f}; // фактор спаду для sampleMax, якщо поточний семпл нижче sampleMax
const float agcZoneLow[AGC_NUM_PRESETS]       = {      32,      28,      36}; // зона низької гучності (екстрена)
const float agcZoneHigh[AGC_NUM_PRESETS]      = {     240,     240,     248}; // зона високої гучності (екстрена)
const float agcZoneStop[AGC_NUM_PRESETS]      = {     336,     448,     304}; // вимкнути інтегратор АРП, якщо ми вище цього рівня
const float agcTarget0[AGC_NUM_PRESETS]       = {     112,     144,     164}; // перша точка уставки АРП -> між 40% і 65%
const float agcTarget0Up[AGC_NUM_PRESETS]     = {      88,      64,     116}; // значення перемикання уставки (бідняцький bang-bang контролер)
const float agcTarget1[AGC_NUM_PRESETS]       = {     220,     224,     216}; // друга точка уставки АРП -> близько 85%
const double agcFollowFast[AGC_NUM_PRESETS]   = { 1/192.f, 1/128.f, 1/256.f}; // швидко слідувати за уставкою - ~0.15 сек
const double agcFollowSlow[AGC_NUM_PRESETS]   = {1/6144.f,1/4096.f,1/8192.f}; // повільно слідувати за уставкою  - ~2-15 сек
const double agcControlKp[AGC_NUM_PRESETS]    = {    0.6f,    1.5f,   0.65f}; // АРП - PI контроль, пропорційний параметр підсилення
const double agcControlKi[AGC_NUM_PRESETS]    = {    1.7f,   1.85f,    1.2f}; // АРП - PI контроль, інтегральний параметр підсилення
const float agcSampleSmooth[AGC_NUM_PRESETS]  = {  1/12.f,   1/6.f,  1/16.f}; // фактор згладжування для sampleAgc (використовуйте rawSampleAgc, якщо хочете незгладжене значення)
// Кінець пресетів АРП

static AudioSource *audioSource = nullptr;
static bool useBandPassFilter = false;                    // якщо true, вмикає смуговий фільтр 80Hz-16Khz для видалення шуму. Застосовується перед FFT.

////////////////////
// Початок коду FFT //
////////////////////

// деякі прототипи для забезпечення узгоджених інтерфейсів
static float fftAddAvg(int from, int to);   // середнє значення декількох бінів результатів FFT
void FFTcode(void * parameter);      // завдання обробки аудіо: читання семплів, запуск FFT, заповнення каналів GEQ з результатів FFT
static void runMicFilter(uint16_t numSamples, float *sampleBuffer);          // попереднє фільтрування сирих семплів (смуговий фільтр)
static void postProcessFFTResults(bool noiseGateOpen, int numberOfChannels); // постобробка та пост-підсилення каналів GEQ

static TaskHandle_t FFT_Task = nullptr;




// Таблиця множників для вирівнювання частотної характеристики.
static float fftResultPink[NUM_GEQ_CHANNELS] = { 1.70f, 1.71f, 1.73f, 1.78f, 1.68f, 1.56f, 1.55f, 1.63f, 1.79f, 1.62f, 1.80f, 2.06f, 2.47f, 3.35f, 6.83f, 9.55f };

// глобальні змінні та вихідні дані FFT, спільні з анімаціями
#if defined(WLED_DEBUG) || defined(SR_DEBUG)
static uint64_t fftTime = 0;
static uint64_t sampleTime = 0;
#endif

// Змінні завдання FFT (фільтрація та постобробка)
static float   fftCalc[NUM_GEQ_CHANNELS] = {0.0f};                    // Спробувати нормалізувати значення fftBin до макс 4096, щоб 4096/16 = 256.
static float   fftAvg[NUM_GEQ_CHANNELS] = {0.0f};                     // Розраховані результати частотних каналів, зі згладжуванням (використовується, якщо лімітер динаміки УВІМКНЕНО)
#ifdef SR_DEBUG
static float   fftResultMax[NUM_GEQ_CHANNELS] = {0.0f};               // Таблиця для тестування, щоб визначити, як працює наша постобробка.
#endif

// параметри та константи аудіоджерела
constexpr SRate_t SAMPLE_RATE = 22050;        // Базова частота дискретизації в Гц - 22Khz це стандарт. Фізичний час вибірки -> 23ms
//constexpr SRate_t SAMPLE_RATE = 16000;        // 16kHz - використовувати, якщо завдання FFT займає більше 20ms.
//constexpr SRate_t SAMPLE_RATE = 20480;        // Базова частота дискретизації в Гц - 20Khz експериментальна.
//constexpr SRate_t SAMPLE_RATE = 10240;        // Базова частота дискретизації в Гц - попередній стандарт.

#define FFT_MIN_CYCLE 21                      // мінімальний час перед повторенням завдання FFT. Використовувати з 22Khz
//#define FFT_MIN_CYCLE 30                      // Використовувати з 16Khz
//#define FFT_MIN_CYCLE 23                      // мінімальний час перед повторенням завдання FFT. Використовувати з 20Khz

// Константи FFT
constexpr uint16_t samplesFFT = 512;            // Кількість семплів у партії FFT - Це значення ЗАВЖДИ має бути ступенем 2
constexpr uint16_t samplesFFT_2 = 256;          // значуща частина результатів FFT - лише "нижня половина" містить корисну інформацію.
// наступні значення є спостережуваними, підкріпленими "обгрунтованим вгадуванням"
//#define FFT_DOWNSCALE 0.65f                                             // 20kHz - фактор зменшення масштабу для результатів FFT
#define FFT_DOWNSCALE 0.46f                                             // фактор зменшення масштабу для результатів FFT - для вікна "Flat-Top" @22Khz
#define LOG_256  5.54517744f                                            // log(256)

// Це вектори входу та виходу. Вхідні вектори отримують розраховані результати від FFT.
static float* vReal = nullptr;                  // Входи семплів FFT / частотний вихід - це наші "сирі" біни результатів
static float* vImag = nullptr;                  // уявні частини

// Створення об'єкта FFT
// lib_deps += https://github.com/kosme/arduinoFFT#develop @ 1.9.2
// ці опції насправді викликають уповільнення на всіх процесорах esp32, не використовуйте їх.
// #define FFT_SPEED_OVER_PRECISION      // вмикає використання обернених величин (1/x тощо) - не швидше на ESP32
// #define FFT_SQRT_APPROXIMATION        // вмикає обернений корінь у стилі "quake3"  - повільніше на ESP32
// Нижче наведені опції змушують ArduinoFFT використовувати sqrtf() замість sqrt()
// #define sqrt_internal sqrtf           // див pull request 83 - починаючи з v2.0.0 це треба робити в build_flags

#include <arduinoFFT.h>             // Об'єкт FFT створюється в FFTcode
// Допоміжні функції

// обчислити середнє значення кількох бінів результатів FFT
static float fftAddAvg(int from, int to) {
  float result = 0.0f;
  for (int i = from; i <= to; i++) {
    result += vReal[i];
  }
  return result / float(to - from + 1);
}

//
// Головне завдання FFT
//
void FFTcode(void * parameter)
{
  DEBUGSR_PRINT("FFT запущено на ядрі: "); DEBUGSR_PRINTLN(xPortGetCoreID());

  // виділити буфери FFT при першому виклику
  if (vReal == nullptr) vReal = (float*) calloc(samplesFFT, sizeof(float));
  if (vImag == nullptr) vImag = (float*) calloc(samplesFFT, sizeof(float));
  if ((vReal == nullptr) || (vImag == nullptr)) {
    // щось пішло не так
    if (vReal) free(vReal); vReal = nullptr;
    if (vImag) free(vImag); vImag = nullptr;
    return;
  }
  // Створити об'єкт FFT зі сховищем вагових коефіцієнтів
  ArduinoFFT<float> FFT = ArduinoFFT<float>( vReal, vImag, samplesFFT, SAMPLE_RATE, true);

  // див https://www.freertos.org/vtaskdelayuntil.html
  const TickType_t xFrequency = FFT_MIN_CYCLE * portTICK_PERIOD_MS;  

  TickType_t xLastWakeTime = xTaskGetTickCount();
  for(;;) {
    delay(1);           // НЕ ВИДАЛЯЙТЕ ЦЕЙ РЯДОК! Він потрібен, щоб дати завданню IDLE(0) час і задовольнити watchdog.
                        // taskYIELD(), yield(), vTaskDelay() та esp_task_wdt_feed(), здається, не працюють.

    // Не запускати код FFT, якщо ми в режимі Отримання (Receive) або в режимі реального часу
    if (disableSoundProcessing || (audioSyncEnabled & 0x02)) {
      vTaskDelayUntil( &xLastWakeTime, xFrequency);        // звільнити CPU, і дозволити I2S заповнити буфери
      continue;
    }

#if defined(WLED_DEBUG) || defined(SR_DEBUG)
    uint64_t start = esp_timer_get_time();
    bool haveDoneFFT = false; // вказує, чи дійсне друге вимірювання (час FFT)
#endif

    // отримати свіжу партію семплів з I2S
    if (audioSource) audioSource->getSamples(vReal, samplesFFT);
    memset(vImag, 0, samplesFFT * sizeof(float));   // встановити уявні частини в 0

#if defined(WLED_DEBUG) || defined(SR_DEBUG)
    if (start < esp_timer_get_time()) { // відфільтрувати переповнення
      uint64_t sampleTimeInMillis = (esp_timer_get_time() - start +5ULL) / 10ULL; // "+5" для правильного округлення
      sampleTime = (sampleTimeInMillis*3 + sampleTime*7)/10; // згладжування
    }
    start = esp_timer_get_time(); // почати вимірювання часу FFT
#endif

    xLastWakeTime = xTaskGetTickCount();        // оновити "час останнього розблокування" для vTaskDelay

    // смуговий фільтр - може знизити рівень шуму в 50 разів
    // недолік: частоти нижче 100Гц будуть ігноруватися
    if (useBandPassFilter) runMicFilter(samplesFFT, vReal);

    // знайти найвищий семпл у партії
    float maxSample = 0.0f;                         // макс семпл з партії FFT
    for (int i=0; i < samplesFFT; i++) {
      // вибрати наш поточний семпл мікрофона - беремо максимальне значення з усіх семплів, що йдуть у FFT
      if ((vReal[i] <= (INT16_MAX - 1024)) && (vReal[i] >= (INT16_MIN + 1024)))  //пропустити екстремальні значення - зазвичай це артефакти
        if (fabsf((float)vReal[i]) > maxSample) maxSample = fabsf((float)vReal[i]);
    }
    // ранній випуск найвищого семплу для ефектів реакції на гучність - не обов'язково тут - можна і в кінці функції
    // ранній випуск дозволяє фільтрам (getSample() та agcAvg()) працювати зі свіжими значеннями.
    micDataReal = maxSample;

#ifdef SR_DEBUG
    if (true) {  // це дозволяє вимірювати час виконання FFT, оскільки вимикає оптимізацію "тільки коли потрібно" 
#else
    if (sampleAvg > 0.25f) { // відкритий шумоподавлювач означає, що результати FFT будуть використані.
#endif

      // запустити FFT (займає 3-5мс на ESP32, ~12мс на ESP32-S2)
      FFT.dcRemoval();                                                        // видалення зміщення DC
      FFT.windowing( FFTWindow::Flat_top, FFTDirection::Forward); // Зважування даних функцією "Flat Top" - краща точність амплітуди
      //FFT.windowing(FFTWindow::Blackman_Harris, FFTDirection::Forward);  // Зважування вікном "Blackman-Harris" - гострі піки
      FFT.compute( FFTDirection::Forward );                                   // Обчислення FFT
      FFT.complexToMagnitude();                                               // Обчислення амплітуд
      vReal[0] = 0;   // Залишкове зміщення DC на сигналі створює сильний пік на позиції 0, який слід усунути.

      FFT.majorPeak(&FFT_MajorPeak, &FFT_Magnitude);                 // повідомити ефекти, яка частота була домінуючою
      FFT_MajorPeak = constrain(FFT_MajorPeak, 1.0f, 11025.0f);   // обмежити значення діапазоном, очікуваним ефектами

#if defined(WLED_DEBUG) || defined(SR_DEBUG)
      haveDoneFFT = true;
#endif

    } else { // шумоподавлювач закритий - очистити результати, оскільки FFT пропущено. Семпли MIC все ще дійсні.
      memset(vReal, 0, samplesFFT * sizeof(float));
      FFT_MajorPeak = 1;
      FFT_Magnitude = 0.001;
    }

    for (int i = 0; i < samplesFFT; i++) {
      float t = fabsf(vReal[i]);                      // про всяк випадок - значення в бінах fft повинні бути позитивними
      vReal[i] = t / 16.0f;                           // Зменшити амплітуду. Хочемо, щоб кінцевий результат був лінійним і макс ~4096.
    } // for()

    // відображення бінів результатів FFT на частотні канали
    if (fabsf(sampleAvg) > 0.5f) { // шумоподавлювач відкритий
#if 0
    /* Це постобробка FFT - це DIY зусилля. Нам потрібен звукоінженер...
     * ... (тут був старий код маппінгу)
     */                                           //  Діапазон
      fftCalc[ 0] = fftAddAvg(2,4);       // 60 - 100
      // ... (старий код пропущено)
      fftCalc[15] = fftAddAvg(194,250);   // 3880 - 5000 // уникаємо останніх 5 бінів, вони зазвичай неточні
#else
      /* нове відображення, оптимізоване для 22050 Hz від softhack007 */
                                                        // біни частота  діапазон
      if (useBandPassFilter) {
        // пропустити частоти нижче 100hz
        fftCalc[ 0] = 0.8f * fftAddAvg(3,4);
        fftCalc[ 1] = 0.9f * fftAddAvg(4,5);
        fftCalc[ 2] = fftAddAvg(5,6);
        fftCalc[ 3] = fftAddAvg(6,7);
        // не використовувати останні біни від 206 до 255. 
        fftCalc[15] = fftAddAvg(165,205) * 0.75f;   // 40 7106 - 8828 високі             -- з деяким демпфуванням
      } else {
        fftCalc[ 0] = fftAddAvg(1,2);               // 1    43 - 86   суб-бас
        fftCalc[ 1] = fftAddAvg(2,3);               // 1    86 - 129  бас
        fftCalc[ 2] = fftAddAvg(3,5);               // 2   129 - 216  бас
        fftCalc[ 3] = fftAddAvg(5,7);               // 2   216 - 301  бас + середні
        // не використовувати останні біни від 216 до 255. Вони зазвичай забруднені аліасингом (шумом) 
        fftCalc[15] = fftAddAvg(165,215) * 0.70f;   // 50 7106 - 9259 високі             -- з деяким демпфуванням
      }
      fftCalc[ 4] = fftAddAvg(7,10);                // 3   301 - 430  середні
      fftCalc[ 5] = fftAddAvg(10,13);               // 3   430 - 560  середні
      fftCalc[ 6] = fftAddAvg(13,19);               // 5   560 - 818  середні
      fftCalc[ 7] = fftAddAvg(19,26);               // 7   818 - 1120 середні -- 1Khz завжди має бути центром!
      fftCalc[ 8] = fftAddAvg(26,33);               // 7  1120 - 1421 середні
      fftCalc[ 9] = fftAddAvg(33,44);               // 9  1421 - 1895 середні
      fftCalc[10] = fftAddAvg(44,56);               // 12 1895 - 2412 середні + високі середні
      fftCalc[11] = fftAddAvg(56,70);               // 14 2412 - 3015 високі середні
      fftCalc[12] = fftAddAvg(70,86);               // 16 3015 - 3704 високі середні
      fftCalc[13] = fftAddAvg(86,104);              // 18 3704 - 4479 високі середні
      fftCalc[14] = fftAddAvg(104,165) * 0.88f;     // 61 4479 - 7106 високі середні + високі  -- з легким демпфуванням
#endif
    } else {  // шумоподавлювач закритий - просто згасання старих значень
      for (int i=0; i < NUM_GEQ_CHANNELS; i++) {
        fftCalc[i] *= 0.85f;  // спад до нуля
        if (fftCalc[i] < 4.0f) fftCalc[i] = 0.0f;
      }
    }

    // постобробка частотних каналів (коригування рожевого шуму, АРП, згладжування, масштабування)
    postProcessFFTResults((fabsf(sampleAvg) > 0.25f)? true : false , NUM_GEQ_CHANNELS);

#if defined(WLED_DEBUG) || defined(SR_DEBUG)
    if (haveDoneFFT && (start < esp_timer_get_time())) { // фільтрувати переповнення
      uint64_t fftTimeInMillis = ((esp_timer_get_time() - start) +5ULL) / 10ULL; // "+5" для правильного округлення
      fftTime  = (fftTimeInMillis*3 + fftTime*7)/10; // згладжування
    }
#endif
    // запустити виявлення піків
    autoResetPeak();
    detectSamplePeak();
     
    #if !defined(I2S_GRAB_ADC1_COMPLETELY)     
    if ((audioSource == nullptr) || (audioSource->getType() != AudioSource::Type_I2SAdc))  // "трюк із затримкою" не допомагає для аналогового ADC
    #endif
      vTaskDelayUntil( &xLastWakeTime, xFrequency);        // звільнити CPU, і дозволити I2S заповнити буфери

  } // for(;;) назавжди
} // Кінець завдання FFTcode()


///////////////////////////
// Попер/Пост-обробка    //
///////////////////////////

static void runMicFilter(uint16_t numSamples, float *sampleBuffer)          // попереднє фільтрування сирих семплів (смуговий фільтр)
{
  // параметр зрізу низьких частот
  //constexpr float alpha = 0.04f;   // 150Hz
  //constexpr float alpha = 0.03f;   // 110Hz
  constexpr float alpha = 0.0225f; // 80hz
  //constexpr float alpha = 0.01693f;// 60hz
  // параметр зрізу високих частот
  //constexpr float beta1 = 0.75f;   // 11Khz
  //constexpr float beta1 = 0.82f;   // 15Khz
  //constexpr float beta1 = 0.8285f; // 18Khz
  constexpr float beta1 = 0.85f;  // 20Khz

  constexpr float beta2 = (1.0f - beta1) / 2.0f;
  static float last_vals[2] = { 0.0f }; // FIR фільтр зрізу високих частот
  static float lowfilt = 0.0f;          // IIR фільтр зрізу низьких частот

  for (int i=0; i < numSamples; i++) {
        // FIR низьких частот, для видалення високочастотного шуму
        float highFilteredSample;
        if (i < (numSamples-1)) highFilteredSample = beta1*sampleBuffer[i] + beta2*last_vals[0] + beta2*sampleBuffer[i+1];  // згладити піки
        else highFilteredSample = beta1*sampleBuffer[i] + beta2*last_vals[0]  + beta2*last_vals[1];                   // спеціальна обробка для останнього семплу
        last_vals[1] = last_vals[0];
        last_vals[0] = sampleBuffer[i];
        sampleBuffer[i] = highFilteredSample;
        // IIR високих частот, для видалення низькочастотного шуму
        lowfilt += alpha * (sampleBuffer[i] - lowfilt);
        sampleBuffer[i] = sampleBuffer[i] - lowfilt;
  }
}



static void postProcessFFTResults(bool noiseGateOpen, int numberOfChannels) // постобробка та пост-підсилення каналів GEQ
{
    for (int i=0; i < numberOfChannels; i++) {

      if (noiseGateOpen) { // шумоподавлювач відкритий
        // Коригування частотних кривих.
        fftCalc[i] *= fftResultPink[i];
        if (FFTScalingMode > 0) fftCalc[i] *= FFT_DOWNSCALE;  // коригування пов'язане з віконною функцією FFT
        // Ручне лінійне коригування підсилення за допомогою sampleGain для різних типів входу.
        fftCalc[i] *= soundAgc ? multAgc : ((float)sampleGain/40.0f * (float)inputLevel/128.0f + 1.0f/16.0f); //застосувати підсилення, з коригуванням inputLevel
        if(fftCalc[i] < 0) fftCalc[i] = 0;
      }

      // згладжування результатів - зростати швидко, падати повільніше
      if(fftCalc[i] > fftAvg[i])   // зростати швидко 
        fftAvg[i] = fftCalc[i] *0.75f + 0.25f*fftAvg[i];  // знадобиться приблизно 2 цикли (50ms) для збігу з fftCalc[i]
      else {                        // падати повільно
        if (decayTime < 1000) fftAvg[i] = fftCalc[i]*0.22f + 0.78f*fftAvg[i];       // приблизно  5 циклів (225ms) для падіння до нуля
        else if (decayTime < 2000) fftAvg[i] = fftCalc[i]*0.17f + 0.83f*fftAvg[i];  // за замовчуванням - приблизно  9 циклів (225ms)
        else if (decayTime < 3000) fftAvg[i] = fftCalc[i]*0.14f + 0.86f*fftAvg[i];  // приблизно 14 циклів (350ms)
        else fftAvg[i] = fftCalc[i]*0.1f  + 0.9f*fftAvg[i];                         // приблизно 20 циклів (500ms)
      }
      // обмежити внутрішні змінні - про всяк випадок
      fftCalc[i] = constrain(fftCalc[i], 0.0f, 1023.0f);
      fftAvg[i] = constrain(fftAvg[i], 0.0f, 1023.0f);

      float currentResult;
      if(limiterOn == true)
        currentResult = fftAvg[i];
      else
        currentResult = fftCalc[i];

      switch (FFTScalingMode) {
        case 1:
            // Логарифмічне масштабування
            currentResult *= 0.42f;                      // 42 це відповідь ;-)
            currentResult -= 8.0f;                       // це пропускає найнижчий рядок, даючи трохи місця для піків
            if (currentResult > 1.0f) currentResult = logf(currentResult); // log за основою "e"
            else currentResult = 0.0f;                   // спец. обробка, тому що log(1) = 0; log(0) = невизначено
            currentResult *= 0.85f + (float(i)/18.0f);  // додаткове підвищення масштабу для високих частот
            currentResult = mapf(currentResult, 0, LOG_256, 0, 255); // відобразити [log(1) ... log(255)] в [0 ... 255]
        break;
        case 2:
            // Лінійне масштабування
            currentResult *= 0.30f;                     // потребує більше демпфування, щоб залишитися нижче 255
            currentResult -= 4.0f;                       // даючи трохи більше місця для піків
            if (currentResult < 1.0f) currentResult = 0.0f;
            currentResult *= 0.85f + (float(i)/1.8f);   // додаткове підвищення масштабу для високих частот
        break;
        case 3:
            // Масштабування квадратним коренем
            currentResult *= 0.38f;
            currentResult -= 6.0f;
            if (currentResult > 1.0f) currentResult = sqrtf(currentResult);
            else currentResult = 0.0f;                   // спец. обробка
            currentResult *= 0.85f + (float(i)/4.5f);   // додаткове підвищення масштабу для високих частот
            currentResult = mapf(currentResult, 0.0, 16.0, 0.0, 255.0); // відобразити [sqrt(1) ... sqrt(256)] в [0 ... 255]
        break;

        case 0:
        default:
            // без масштабування - залишити частотні біни як є
            currentResult -= 4; // просто трохи більше місця для піків
        break;
      }

      // Тепер скинемо все це в fftResult.
      if (soundAgc > 0) {  // застосувати додаткове "Підсилення GEQ", якщо встановлено користувачем
        float post_gain = (float)inputLevel/128.0f;
        if (post_gain < 1.0f) post_gain = ((post_gain -1.0f) * 0.8f) +1.0f;
        currentResult *= post_gain;
      }
      fftResult[i] = constrain((int)currentResult, 0, 255);
    }
}
////////////////////
// Виявлення піків//
////////////////////

// виявлення піків викликається з завдання FFT, коли vReal[] містить дійсні результати
static void detectSamplePeak(void) {
  bool havePeak = false;
  // softhack007: цей код постійно спрацьовує, поки амплітуда у вибраному біні вище певного порогу.
  // Бідняцьке виявлення біта, перевіряючи, чи sample > Average + деяке значення.
  if ((sampleAvg > 1) && (maxVol > 0) && (binNum > 4) && (vReal[binNum] > maxVol) && ((millis() - timeOfPeak) > 100)) {
    havePeak = true;
  }

  if (havePeak) {
    samplePeak    = true;
    timeOfPeak    = millis();
    udpSamplePeak = true;
  }
}

#endif

static void autoResetPeak(void) {
  uint16_t peakDelay = max(uint16_t(50), strip.getFrameTime());
  if (millis() - timeOfPeak > peakDelay) {          // Автоскидання samplePeak після проходження принаймні одного повного кадру.
    samplePeak = false;
    if (audioSyncEnabled == 0) udpSamplePeak = false;  // це зазвичай скидається через transmitAudioData
  }
}


////////////////////
// клас usermod   //
////////////////////

//ім'я класу. Використовуйте щось описове :)
class AudioReactive : public Usermod {

  private:
#ifdef ARDUINO_ARCH_ESP32

    #ifndef AUDIOPIN
    int8_t audioPin = -1;
    #else
    int8_t audioPin = AUDIOPIN;
    #endif
    #ifndef SR_DMTYPE // Тип мікрофона I2S
    uint8_t dmType = 1; // 0=немає/вимк/аналог; 1=загальний I2S
    #define SR_DMTYPE 1 // тип за замовчуванням = I2S
    #else
    uint8_t dmType = SR_DMTYPE;
    #endif
    #ifndef I2S_SDPIN // aka DOUT
    int8_t i2ssdPin = 32;
    #else
    int8_t i2ssdPin = I2S_SDPIN;
    #endif
    #ifndef I2S_WSPIN // aka LRCL
    int8_t i2swsPin = 15;
    #else
    int8_t i2swsPin = I2S_WSPIN;
    #endif
    #ifndef I2S_CKPIN // aka BCLK
    int8_t i2sckPin = 14; /*PDM: встановити I2S_PIN_NO_CHANGE*/
    #else
    int8_t i2sckPin = I2S_CKPIN;
    #endif
    #ifndef MCLK_PIN
    int8_t mclkPin = I2S_PIN_NO_CHANGE;  /* ESP32: дозволено лише -1, 0, 1, 3*/
    #else
    int8_t mclkPin = MCLK_PIN;
    #endif
#endif

    // нова структура audiosync "V2" - 44 байти
    struct __attribute__ ((packed)) audioSyncPacket {  // "packed" гарантує відсутність додаткових прогалин
      char    header[6];      //  06 Байтів offset 0
      uint8_t reserved1[2];   //  02 Байтів, offset 6  - прогалина для компілятора
      float   sampleRaw;      //  04 Байтів offset 8
      float   sampleSmth;     //  04 Байтів offset 12
      uint8_t samplePeak;     //  01 Байтів offset 16 - 0 немає піку; >=1 пік виявлено
      uint8_t reserved2;      //  01 Байтів offset 17
      uint8_t fftResult[16];  //  16 Байтів offset 18
      uint16_t reserved3;     //  02 Байтів, offset 34
      float  FFT_Magnitude;   //  04 Байтів offset 36
      float  FFT_MajorPeak;   //  04 Байтів offset 40
    };

    // стара структура audiosync "V1" - для зворотної сумісності
    struct audioSyncPacket_v1 {
      char header[6];         //  06 Байтів
      uint8_t myVals[32];     //  32 Байтів
      int sampleAgc;          //  04 Байтів
      int sampleRaw;          //  04 Байтів
      float sampleAvg;        //  04 Байтів
      bool samplePeak;        //  01 Байтів
      uint8_t fftResult[16];  //  16 Байтів
      double FFT_Magnitude;   //  08 Байтів
      double FFT_MajorPeak;   //  08 Байтів
    };

    #define UDPSOUND_MAX_PACKET 88 // макс розмір пакету для audiosync

    // встановіть ваші змінні конфігурації у значення за замовчуванням
    #ifdef UM_AUDIOREACTIVE_ENABLE
    bool     enabled = true;
    #else
    bool     enabled = false;
    #endif

    bool     initDone = false;
    bool     addPalettes = false;
    int8_t   palettes = 0;

    // змінні для UDP синхронізації звуку
    WiFiUDP fftUdp;               // Об'єкт UDP для синхронізації
    unsigned long lastTime = 0;   // останній час запуску UDP Microphone Sync
    const uint16_t delayMs = 10;  // Не хочу семплювати надто часто і перевантажувати WLED
    uint16_t audioSyncPort= 11988;// порт за замовчуванням для UDP sound sync

    bool updateIsRunning = false; // true під час OTA (оновлення прошивки).

#ifdef ARDUINO_ARCH_ESP32
    // використовується для АРП (AGC)
    int      last_soundAgc = -1;   // для виявлення зміни режиму АРП
    double   control_integrated = 0.0;   // персистентне між викликами agcAvg(); "контроль інтегратора"


    // змінні, що використовуються getSample() та agcAvg()
    int16_t  micIn = 0;           // Поточний семпл
    double   sampleMax = 0.0;     // Макс семпл за кілька секунд. Потрібен для контролера АРП.
    double   micLev = 0.0;        // Використовується для конвертації значення, щоб '0' був мінімумом. Вирівнювач
    float    expAdjF = 0.0f;      // Використовується для експоненційного фільтра.
    float    sampleReal = 0.0f;   // "sampleRaw" як float
    int16_t  sampleRaw = 0;       // Поточний семпл. Повинен оновлюватися лише ОДИН РАЗ!!! (підсилене значення мікрофона)
    int16_t  rawSampleAgc = 0;    // незгладжений семпл АРП
#endif

    // змінні, що використовуються в ефектах
    float    volumeSmth = 0.0f;    // або sampleAvg, або sampleAgc залежно від soundAgc; згладжений семпл
    int16_t  volumeRaw = 0;        // або sampleRaw, або rawSampleAgc залежно від soundAgc
    float my_magnitude =0.0f;      // FFT_Magnitude, масштабоване через multAgc

    // використовується для сторінки "Info"
    unsigned long last_UDPTime = 0;    // час останнього дійсного пакету UDP sound sync
    int receivedFormat = 0;            // формат останнього отриманого UDP
    float maxSample5sec = 0.0f;        // макс семпл (після АРП) за останні 5 секунд 
    unsigned long sampleMaxTimer = 0;  // останній час скидання maxSample5sec
    #define CYCLE_SAMPLEMAX 3500       // вікно часу для вимірювання

    // рядки для зменшення використання флеш-пам'яті (використовуються більше двох разів)
    static const char _name[];
    static const char _enabled[];
    static const char _config[];
    static const char _dynamics[];
    static const char _frequency[];
    static const char _inputLvl[];
#if defined(ARDUINO_ARCH_ESP32) && !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3) && !defined(CONFIG_IDF_TARGET_ESP32S3)
    static const char _analogmic[];
#endif
    static const char _digitalmic[];
    static const char _addPalettes[];
    static const char UDP_SYNC_HEADER[];
    static const char UDP_SYNC_HEADER_v1[];

    // приватні методи
    void removeAudioPalettes(void);
    void createAudioPalettes(void);
    CRGB getCRGBForBand(int x, int pal);
    void fillAudioPalettes(void);

    ////////////////////
    // Підтримка Debug//
    ////////////////////
    void logAudio()
    {
      if (disableSoundProcessing && (!udpSyncConnected || ((audioSyncEnabled & 0x02) == 0))) return;   // немає доступного аудіо
    #ifdef MIC_LOGGER
      // Функції налагодження для аудіо входу та обробки звуку. Розкоментуйте значення, які хочете бачити
      PLOT_PRINT("micReal:");     PLOT_PRINT(micDataReal); PLOT_PRINT("\t");
      PLOT_PRINT("volumeSmth:");  PLOT_PRINT(volumeSmth);  PLOT_PRINT("\t");
      //PLOT_PRINT("volumeRaw:");   PLOT_PRINT(volumeRaw);   PLOT_PRINT("\t");
      PLOT_PRINT("DC_Level:");    PLOT_PRINT(micLev);      PLOT_PRINT("\t");
    #ifdef ARDUINO_ARCH_ESP32
      //PLOT_PRINT("micIn:");       PLOT_PRINT(micIn);       PLOT_PRINT("\t");
      //PLOT_PRINT("multAgc:");     PLOT_PRINT(multAgc, 4);  PLOT_PRINT("\t");
    #endif
      PLOT_PRINTLN();
    #endif

    #ifdef FFT_SAMPLING_LOG
      // ... (код логування FFT пропущено для стислості, він великий і для тестів)
    #endif // FFT_SAMPLING_LOG
    } // logAudio()


#ifdef ARDUINO_ARCH_ESP32
    //////////////////////
    // Обробка Аудіо    //
    //////////////////////

    /*
    * Множник "PI контролера" для автоматичного регулювання чутливості звуку.
    * * Реалізовано кілька трюків, щоб sampleAgc не використовував лише 0% і 100%:
    * 0. не підсилювати нічого нижче порогу шуму (squelch)
    * 1. вхід підсилення = максимальний сигнал за останні 5-10 секунд
    * 2. ми використовуємо дві уставки, одну на ~60%, і одну на ~80% макс сигналу
    * 3. підсилення залежить від рівня сигналу:
    * a) нормальна зона - дуже повільне регулювання
    * b) екстрена зона (<10% або >90%) - дуже швидке регулювання
    */
    void agcAvg(unsigned long the_time)
    {
      const int AGC_preset = (soundAgc > 0)? (soundAgc-1): 0; // переконатися, що компілятор знає, що це значення не зміниться

      float lastMultAgc = multAgc;       // останній використаний множник
      float multAgcTemp = multAgc;       // новий множник
      float tmpAgc = sampleReal * multAgc;        // гіпотетичний посилений сигнал

      float control_error;                                // вхід "помилки керування" для PI контролю

      if (last_soundAgc != soundAgc)
        control_integrated = 0.0;                // новий пресет - скидання інтегратора

      // Для PI контролера нам потрібна постійна "частота"
      static unsigned long last_time = 0;
      unsigned long time_now = millis();
      if ((the_time > 0) && (the_time < time_now)) time_now = the_time;  // дозволити викликаючому перевизначити годинник

      if (time_now - last_time > 2)  {
        last_time = time_now;

        if((fabsf(sampleReal) < 2.0f) || (sampleMax < 1.0)) {
          // Сигнал MIC "заглушено" - видавати тишу
          tmpAgc = 0;
          // треба "розкрутити вниз" інтегрований буфер помилок
          if (fabs(control_integrated) < 0.01)  control_integrated  = 0.0;
          else                                  control_integrated *= 0.91;
        } else {
          // обчислити нову уставку
          if (tmpAgc <= agcTarget0Up[AGC_preset])
            multAgcTemp = agcTarget0[AGC_preset] / sampleMax;   // Зробити множник так, щоб sampleMax * multiplier = перша уставка
          else
            multAgcTemp = agcTarget1[AGC_preset] / sampleMax;   // Зробити множник так, щоб sampleMax * multiplier = друга уставка
        }
        // обмежити підсилення
        if (multAgcTemp > 32.0f)      multAgcTemp = 32.0f;
        if (multAgcTemp < 1.0f/64.0f) multAgcTemp = 1.0f/64.0f;

        // обчислити терми помилок
        control_error = multAgcTemp - lastMultAgc;
        
        if (((multAgcTemp > 0.085f) && (multAgcTemp < 6.5f))    //анти-накрутка інтегратора через обмеження
            && (multAgc*sampleMax < agcZoneStop[AGC_preset]))   //стеля інтегратора (>140% від макс)
          control_integrated += control_error * 0.002 * 0.25;   // 2ms = час інтеграції; 0.25 для демпфування
        else
          control_integrated *= 0.9;                            // розкрутити вниз цей звірячий інтегратор

        // застосувати PI Контроль 
        tmpAgc = sampleReal * lastMultAgc;                      // перевірити "зону" сигналу використовуючи попереднє підсилення
        if ((tmpAgc > agcZoneHigh[AGC_preset]) || (tmpAgc < soundSquelch + agcZoneLow[AGC_preset])) {  // верхня/нижня енергетична зона
          multAgcTemp = lastMultAgc + agcFollowFast[AGC_preset] * agcControlKp[AGC_preset] * control_error;
          multAgcTemp += agcFollowFast[AGC_preset] * agcControlKi[AGC_preset] * control_integrated;
        } else {                                                                                        // "нормальна зона"
          multAgcTemp = lastMultAgc + agcFollowSlow[AGC_preset] * agcControlKp[AGC_preset] * control_error;
          multAgcTemp += agcFollowSlow[AGC_preset] * agcControlKi[AGC_preset] * control_integrated;
        }

        // знову обмежити підсилення - PI контролер іноді "проскакує"
        //multAgcTemp = constrain(multAgcTemp, 0.015625f, 32.0f); // 1/64 < multAgcTemp < 32
        if (multAgcTemp > 32.0f)      multAgcTemp = 32.0f;
        if (multAgcTemp < 1.0f/64.0f) multAgcTemp = 1.0f/64.0f;
      }

      // ТЕПЕР нарешті підсилити сигнал
      tmpAgc = sampleReal * multAgcTemp;                  // застосувати підсилення до сигналу
      if (fabsf(sampleReal) < 2.0f) tmpAgc = 0.0f;        // застосувати поріг шумоподавлення
      //tmpAgc = constrain(tmpAgc, 0, 255);
      if (tmpAgc > 255) tmpAgc = 255.0f;                  // обмежити до 8 біт
      if (tmpAgc < 1)   tmpAgc = 0.0f;                    // про всяк випадок

      // оновити глобальні змінні ОДИН РАЗ - multAgc, sampleAGC, rawSampleAgc
      multAgc = multAgcTemp;
      rawSampleAgc = 0.8f * tmpAgc + 0.2f * (float)rawSampleAgc;
      // оновити згладжений семпл АРП
      if (fabsf(tmpAgc) < 1.0f) 
        sampleAgc =  0.5f * tmpAgc + 0.5f * sampleAgc;    // швидкий шлях до нуля
      else
        sampleAgc += agcSampleSmooth[AGC_preset] * (tmpAgc - sampleAgc); // згладжений шлях

      sampleAgc = fabsf(sampleAgc);                                      // переконатися, що маємо позитивне значення
      last_soundAgc = soundAgc;
    } // agcAvg()

    // постобробка та фільтрація семплу MIC (micDataReal) з FFTcode()
    void getSample()
    {
      float    sampleAdj;           // Скориговане підсиленням значення семплу
      float    tmpSample;           // Проміжна змінна семплу.
      const float weighting = 0.2f; // Вага експоненційного фільтра. Буде налаштовуватися в майбутньому релізі.
      const int    AGC_preset = (soundAgc > 0)? (soundAgc-1): 0; 

      #ifdef WLED_DISABLE_SOUND
        micIn = perlin8(millis(), millis());          // Симульоване аналогове читання
        micDataReal = micIn;
      #else
        #ifdef ARDUINO_ARCH_ESP32
        micIn = int(micDataReal);       // micDataSm = ((micData * 3) + micData)/4;
        #else
        // це мінімальний код для читання аналогового мікрофона на 8266.
        // попередження!! Абсолютно експериментальний код.
        static unsigned long lastAnalogTime = 0;
        static float lastAnalogValue = 0.0f;
        if (millis() - lastAnalogTime > 20) {
            micDataReal = analogRead(A0); // читати один семпл з 10-бітною роздільною здатністю.
            lastAnalogTime = millis();
            lastAnalogValue = micDataReal;
            yield();
        } else micDataReal = lastAnalogValue;
        micIn = int(micDataReal);
        #endif
      #endif

      micLev += (micDataReal-micLev) / 12288.0f;
      if(micIn < micLev) micLev = ((micLev * 31.0f) + micDataReal) / 32.0f; // вирівняти MicLev до найнижчого вхідного сигналу

      micIn -= micLev;                                      // Давайте тепер відцентруємо це до 0
      // Використання експоненційного фільтра для згладжування сигналу.
      float micInNoDC = fabsf(micDataReal - micLev);
      expAdjF = (weighting * micInNoDC + (1.0f-weighting) * expAdjF);
      expAdjF = fabsf(expAdjF);                             // Тепер (!) взяти абсолютне значення

      expAdjF = (expAdjF <= soundSquelch) ? 0: expAdjF; // простий шумоподавлювач (noise gate)
      if ((soundSquelch == 0) && (expAdjF < 0.25f)) expAdjF = 0; // робити щось значуще, коли "squelch = 0"

      tmpSample = expAdjF;
      micIn = abs(micIn);                                   // І отримати абсолютне значення кожного семплу

      sampleAdj = tmpSample * sampleGain / 40.0f * inputLevel/128.0f + tmpSample / 16.0f; // Відрегулювати підсилення. з коригуванням inputLevel
      sampleReal = tmpSample;

      sampleAdj = fmax(fmin(sampleAdj, 255), 0);        // Питання: чому ми обмежуємо значення до 8 біт ???
      sampleRaw = (int16_t)sampleAdj;                   // ТІЛЬКИ оновлювати sample ОДИН РАЗ!!!!

      // зберігати "піковий" семпл, але зменшувати значення, якщо поточний семпл нижче пікового
      if ((sampleMax < sampleReal) && (sampleReal > 0.5f)) {
        sampleMax = sampleMax + 0.5f * (sampleReal - sampleMax);  // новий пік - з деякою фільтрацією
        // інший простий спосіб виявлення samplePeak - не може виявити біти, але реагує на пікову гучність
        if (((binNum < 12) || ((maxVol < 1))) && (millis() - timeOfPeak > 80) && (sampleAvg > 1)) {
          samplePeak    = true;
          timeOfPeak    = millis();
          udpSamplePeak = true;
        }
      } else {
        if ((multAgc*sampleMax > agcZoneStop[AGC_preset]) && (soundAgc > 0))
          sampleMax += 0.5f * (sampleReal - sampleMax);        // понад зону АРП - швидко повернутися
        else
          sampleMax *= agcSampleDecay[AGC_preset];             // сигнал до нуля --> 5-8сек
      }
      if (sampleMax < 0.5f) sampleMax = 0.0f;

      sampleAvg = ((sampleAvg * 15.0f) + sampleAdj) / 16.0f;   // Згладити це за останні 16 семплів.
      sampleAvg = fabsf(sampleAvg);                            // переконатися, що маємо позитивне значення
    } // getSample()

#endif



/* Обмежує динаміку volumeSmth (= sampleAvg або sampleAgc). 
     * не впливає на FFTResult[] або volumeRaw ( = sample або rawSampleAgc) 
     */
    // ефекти: Gravimeter, Gravcenter, Gravcentric, Noisefire, Plasmoid, Freqpixels, Freqwave, Gravfreq, (2D Swirl, 2D Waverly)
    void limitSampleDynamics(void) {
      const float bigChange = 196;                  // просто репрезентативне число - велике очікуване значення семплу
      static unsigned long last_time = 0;
      static float last_volumeSmth = 0.0f;

      if (limiterOn == false) return;

      long delta_time = millis() - last_time;
      delta_time = constrain(delta_time , 1, 1000); // нижче 1мс -> 1мс; вище 1сек -> дурний збій
      float deltaSample = volumeSmth - last_volumeSmth;

      if (attackTime > 0) {                         // користувач визначив час атаки > 0
        float maxAttack =  bigChange * float(delta_time) / float(attackTime);
        if (deltaSample > maxAttack) deltaSample = maxAttack;
      }
      if (decayTime > 0) {                          // користувач визначив час спаду > 0
        float maxDecay  = - bigChange * float(delta_time) / float(decayTime);
        if (deltaSample < maxDecay) deltaSample = maxDecay;
      }

      volumeSmth = last_volumeSmth + deltaSample; 

      last_volumeSmth = volumeSmth;
      last_time = millis();
    }


    //////////////////////
    // UDP Sound Sync   //
    //////////////////////

    // спробувати встановити з'єднання UDP sound sync
    void connectUDPSoundSync(void) {
      // Ця функція намагається встановити UDP sync з'єднання, якщо потрібно
      // необхідно, оскільки ми також хочемо передавати в "AP Mode", але стандартний зворотний виклик "connected()" реагує тільки на STA підключення
      static unsigned long last_connection_attempt = 0;

      if ((audioSyncPort <= 0) || ((audioSyncEnabled & 0x03) == 0)) return;  // Sound Sync не увімкнено
      if (udpSyncConnected) return;                                          // вже підключено
      if (!(apActive || interfacesInited)) return;                           // ні AP, ні інші підключення недоступні
      if (millis() - last_connection_attempt < 15000) return;                // пробувати лише раз на 15 секунд
      if (updateIsRunning) return; 

      // якщо ми тут, нам потрібне UDP з'єднання, але його немає
      last_connection_attempt = millis();
      connected(); // спробувати запустити UDP
    }

#ifdef ARDUINO_ARCH_ESP32
    void transmitAudioData()
    {
      if (!udpSyncConnected) return;
      //DEBUGSR_PRINTLN("Передача пакету UDP Mic");

      audioSyncPacket transmitData;
      memset(reinterpret_cast<void *>(&transmitData), 0, sizeof(transmitData)); // переконатися, що пакет - включаючи "невидимі" байти заповнення, додані компілятором - повністю ініціалізований

      strncpy_P(transmitData.header, PSTR(UDP_SYNC_HEADER), 6);
      // передавати семпли, які не були змінені limitSampleDynamics()
      transmitData.sampleRaw   = (soundAgc) ? rawSampleAgc: sampleRaw;
      transmitData.sampleSmth  = (soundAgc) ? sampleAgc    : sampleAvg;
      transmitData.samplePeak  = udpSamplePeak ? 1:0;
      udpSamplePeak            = false;           // Скинути udpSamplePeak після передачі

      for (int i = 0; i < NUM_GEQ_CHANNELS; i++) {
        transmitData.fftResult[i] = (uint8_t)constrain(fftResult[i], 0, 254);
      }

      transmitData.FFT_Magnitude = my_magnitude;
      transmitData.FFT_MajorPeak = FFT_MajorPeak;

      if (fftUdp.beginMulticastPacket() != 0) { // beginMulticastPacket повертає 0 у випадку помилки
        fftUdp.write(reinterpret_cast<uint8_t *>(&transmitData), sizeof(transmitData));
        fftUdp.endPacket();
      }
      return;
    } // transmitAudioData()

#endif

    static bool isValidUdpSyncVersion(const char *header) {
      return strncmp_P(header, UDP_SYNC_HEADER, 6) == 0;
    }
    static bool isValidUdpSyncVersion_v1(const char *header) {
      return strncmp_P(header, UDP_SYNC_HEADER_v1, 6) == 0;
    }

    void decodeAudioData(int packetSize, uint8_t *fftBuff) {
      audioSyncPacket receivedPacket;
      memset(&receivedPacket, 0, sizeof(receivedPacket));                                      // почати з чистого листа
      memcpy(&receivedPacket, fftBuff, min((unsigned)packetSize, (unsigned)sizeof(receivedPacket))); // не порушувати вирівнювання

      // оновити семпли для ефектів
      volumeSmth   = fmaxf(receivedPacket.sampleSmth, 0.0f);
      volumeRaw    = fmaxf(receivedPacket.sampleRaw, 0.0f);
#ifdef ARDUINO_ARCH_ESP32
      // оновити внутрішні семпли
      sampleRaw    = volumeRaw;
      sampleAvg    = volumeSmth;
      rawSampleAgc = volumeRaw;
      sampleAgc    = volumeSmth;
      multAgc      = 1.0f;   
#endif
      // Змінювати samplePeak ТІЛЬКИ ЯКЩО він зараз false.
      // Якщо він вже true, анімація все ще повинна відреагувати.
      autoResetPeak();
      if (!samplePeak) {
            samplePeak = receivedPacket.samplePeak >0 ? true:false;
            if (samplePeak) timeOfPeak = millis();
            //userVar1 = samplePeak;
      }
      //Ці значення обчислюються тільки на ESP32
      for (int i = 0; i < NUM_GEQ_CHANNELS; i++) fftResult[i] = receivedPacket.fftResult[i];
      my_magnitude  = fmaxf(receivedPacket.FFT_Magnitude, 0.0f);
      FFT_Magnitude = my_magnitude;
      FFT_MajorPeak = constrain(receivedPacket.FFT_MajorPeak, 1.0f, 11025.0f);  // обмежити значення діапазоном, очікуваним ефектами
    }

    void decodeAudioData_v1(int packetSize, uint8_t *fftBuff) {
      audioSyncPacket_v1 *receivedPacket = reinterpret_cast<audioSyncPacket_v1*>(fftBuff);
      // оновити семпли для ефектів
      volumeSmth   = fmaxf(receivedPacket->sampleAgc, 0.0f);
      volumeRaw    = volumeSmth;   // V1 формат не має "raw" AGC семплу
#ifdef ARDUINO_ARCH_ESP32
      // оновити внутрішні семпли
      sampleRaw    = fmaxf(receivedPacket->sampleRaw, 0.0f);
      sampleAvg    = fmaxf(receivedPacket->sampleAvg, 0.0f);;
      sampleAgc    = volumeSmth;
      rawSampleAgc = volumeRaw;
      multAgc      = 1.0f;
#endif 
      // Змінювати samplePeak ТІЛЬКИ ЯКЩО він зараз false.
      autoResetPeak();
      if (!samplePeak) {
            samplePeak = receivedPacket->samplePeak >0 ? true:false;
            if (samplePeak) timeOfPeak = millis();
            //userVar1 = samplePeak;
      }
      //Ці значення доступні лише на ESP32
      for (int i = 0; i < NUM_GEQ_CHANNELS; i++) fftResult[i] = receivedPacket->fftResult[i];
      my_magnitude  = fmaxf(receivedPacket->FFT_Magnitude, 0.0);
      FFT_Magnitude = my_magnitude;
      FFT_MajorPeak = constrain(receivedPacket->FFT_MajorPeak, 1.0, 11025.0);  // обмежити значення
    }

    bool receiveAudioData()   // перевірити та обробити нові дані. повернути TRUE, якщо нові аудіодані отримано. 
    {
      if (!udpSyncConnected) return false;
      bool haveFreshData = false;

      size_t packetSize = fftUdp.parsePacket();
#ifdef ARDUINO_ARCH_ESP32
      if ((packetSize > 0) && ((packetSize < 5) || (packetSize > UDPSOUND_MAX_PACKET))) fftUdp.flush(); // відкинути недійсні пакети (надто малі або великі)
#endif
      if ((packetSize > 5) && (packetSize <= UDPSOUND_MAX_PACKET)) {
        //DEBUGSR_PRINTLN("Отримано пакет UDP Sync");
        uint8_t fftBuff[UDPSOUND_MAX_PACKET+1] = { 0 }; // буфер фіксованого розміру для отримання (stack)
        fftUdp.read(fftBuff, packetSize);

        // ПЕРЕВІРИТИ, ЩО ЦЕ СУМІСНИЙ ПАКЕТ
        if (packetSize == sizeof(audioSyncPacket) && (isValidUdpSyncVersion((const char *)fftBuff))) {
          decodeAudioData(packetSize, fftBuff);
          //DEBUGSR_PRINTLN("Завершено розбір UDP Sync Packet v2");
          haveFreshData = true;
          receivedFormat = 2;
        } else {
          if (packetSize == sizeof(audioSyncPacket_v1) && (isValidUdpSyncVersion_v1((const char *)fftBuff))) {
            decodeAudioData_v1(packetSize, fftBuff);
            //DEBUGSR_PRINTLN("Завершено розбір UDP Sync Packet v1");
            haveFreshData = true;
            receivedFormat = 1;
          } else receivedFormat = 0; // невідомий формат
        }
      }
      return haveFreshData;
    }


    //////////////////////
    // функції usermod  //
    //////////////////////

  public:
    //Функції, що викликаються WLED або іншими usermods

    /*
     * setup() викликається один раз при завантаженні. WiFi ще не підключено в цей момент.
     * Ви можете використовувати це для ініціалізації змінних, сенсорів тощо.
     * Викликається *ПІСЛЯ* readFromConfig()
     */
    void setup() override
    {
      disableSoundProcessing = true; // просто щоб бути впевненим
      if (!initDone) {
        // обмін даними usermod
        // ми призначимо всі дані, що експортуються usermod, як вказівники на оригінальні змінні або масиви
        um_data = new um_data_t;
        um_data->u_size = 8;
        um_data->u_type = new um_types_t[um_data->u_size];
        um_data->u_data = new void*[um_data->u_size];
        um_data->u_data[0] = &volumeSmth;       //*використовується (New)
        um_data->u_type[0] = UMT_FLOAT;
        um_data->u_data[1] = &volumeRaw;       // використовується (New)
        um_data->u_type[1] = UMT_UINT16;
        um_data->u_data[2] = fftResult;        //*використовується (Blurz, DJ Light, Noisemove, GEQ_base, 2D Funky Plank, Akemi)
        um_data->u_type[2] = UMT_BYTE_ARR;
        um_data->u_data[3] = &samplePeak;      //*використовується (Puddlepeak, Ripplepeak, Waterfall)
        um_data->u_type[3] = UMT_BYTE;
        um_data->u_data[4] = &FFT_MajorPeak;   //*використовується (Ripplepeak, Freqmap, Freqmatrix, Freqpixels, Freqwave, Gravfreq, Rocktaves, Waterfall)
        um_data->u_type[4] = UMT_FLOAT;
        um_data->u_data[5] = &my_magnitude;    // використовується (New)
        um_data->u_type[5] = UMT_FLOAT;
        um_data->u_data[6] = &maxVol;          // призначається у функції ефекту з елемента UI!!! (Puddlepeak, Ripplepeak, Waterfall)
        um_data->u_type[6] = UMT_BYTE;
        um_data->u_data[7] = &binNum;          // призначається у функції ефекту з елемента UI!!! (Puddlepeak, Ripplepeak, Waterfall)
        um_data->u_type[7] = UMT_BYTE;
      }


#ifdef ARDUINO_ARCH_ESP32

      // Скинути периферію I2S про всяк випадок
      i2s_driver_uninstall(I2S_NUM_0);   // E (696) I2S: i2s_driver_uninstall(2006): I2S port 0 has not installed
      #if !defined(CONFIG_IDF_TARGET_ESP32C3)
        delay(100);
        periph_module_reset(PERIPH_I2S0_MODULE);   // неможливо на -C3
      #endif
      delay(100);         // Дати бідному мікрофону трохи часу на налаштування.

      useBandPassFilter = false;

      #if !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3)
        if ((i2sckPin == I2S_PIN_NO_CHANGE) && (i2ssdPin >= 0) && (i2swsPin >= 0) && ((dmType == 1) || (dmType == 4)) ) dmType = 5;   // підтримка "дурного користувача": SCK == -1 --означає--> PDM мікрофон
      #endif

      switch (dmType) {
      #if defined(CONFIG_IDF_TARGET_ESP32S2) || defined(CONFIG_IDF_TARGET_ESP32C3) || defined(CONFIG_IDF_TARGET_ESP32S3)
        // заглушки для ще не підтримуваних режимів I2S на інших чіпах ESP32
        case 0:  //ADC аналог
        #if defined(CONFIG_IDF_TARGET_ESP32S2) || defined(CONFIG_IDF_TARGET_ESP32C3)
        case 5:  //PDM Мікрофон
        #endif
      #endif
        case 1:
          DEBUGSR_PRINT(F("AR: Generic I2S Microphone - ")); DEBUGSR_PRINTLN(F(I2S_MIC_CHANNEL_TEXT));
          audioSource = new I2SSource(SAMPLE_RATE, BLOCK_SIZE);
          delay(100);
          if (audioSource) audioSource->initialize(i2swsPin, i2ssdPin, i2sckPin);
          break;
        case 2:
          DEBUGSR_PRINTLN(F("AR: ES7243 Microphone (правий канал тільки)."));
          audioSource = new ES7243(SAMPLE_RATE, BLOCK_SIZE);
          delay(100);
          if (audioSource) audioSource->initialize(i2swsPin, i2ssdPin, i2sckPin, mclkPin);
          break;
        case 3:
          DEBUGSR_PRINT(F("AR: SPH0645 Microphone - ")); DEBUGSR_PRINTLN(F(I2S_MIC_CHANNEL_TEXT));
          audioSource = new SPH0654(SAMPLE_RATE, BLOCK_SIZE);
          delay(100);
          audioSource->initialize(i2swsPin, i2ssdPin, i2sckPin);
          break;
        case 4:
          DEBUGSR_PRINT(F("AR: Generic I2S Microphone with Master Clock - ")); DEBUGSR_PRINTLN(F(I2S_MIC_CHANNEL_TEXT));
          audioSource = new I2SSource(SAMPLE_RATE, BLOCK_SIZE, 1.0f/24.0f);
          delay(100);
          if (audioSource) audioSource->initialize(i2swsPin, i2ssdPin, i2sckPin, mclkPin);
          break;
        #if  !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3)
        case 5:
          DEBUGSR_PRINT(F("AR: I2S PDM Microphone - ")); DEBUGSR_PRINTLN(F(I2S_PDM_MIC_CHANNEL_TEXT));
          audioSource = new I2SSource(SAMPLE_RATE, BLOCK_SIZE, 1.0f/4.0f);
          useBandPassFilter = true;  // це знижує рівень шуму на SPM1423 з 5% Vpp (~380) до 0.05% Vpp (~5)
          delay(100);
          if (audioSource) audioSource->initialize(i2swsPin, i2ssdPin);
          break;
        #endif
        case 6:
          DEBUGSR_PRINTLN(F("AR: ES8388 Source"));
          audioSource = new ES8388Source(SAMPLE_RATE, BLOCK_SIZE);
          delay(100);
          if (audioSource) audioSource->initialize(i2swsPin, i2ssdPin, i2sckPin, mclkPin);
          break;

        #if  !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3) && !defined(CONFIG_IDF_TARGET_ESP32S3)
        // ADC через I2S можливо тільки на "класичному" ESP32
        case 0:
          DEBUGSR_PRINTLN(F("AR: Аналоговий мікрофон (лівий канал тільки)."));
          audioSource = new I2SAdcSource(SAMPLE_RATE, BLOCK_SIZE);
          delay(100);
          useBandPassFilter = true;  // PDM смуговий фільтр допомагає для поганої якості аналогу
          if (audioSource) audioSource->initialize(audioPin);
          break;
        #endif

        case 254: // фіктивний режим "тільки прийом по мережі"
          if (audioSource) delete audioSource; audioSource = nullptr;
          disableSoundProcessing = true;
          audioSyncEnabled = 2; // примусовий режим отримання udp sound
          enabled = true;
          break;

        case 255: // 255 = -1 = немає джерела аудіо
          // перехід до default
        default:
          if (audioSource) delete audioSource; audioSource = nullptr;
          disableSoundProcessing = true;
          enabled = false;
        break;
      }
      delay(250); // дати мікрофону достатньо часу на ініціалізацію

      if (!audioSource && (dmType != 254)) enabled = false;// аудіо не вдалося ініціалізувати
#endif
      if (enabled) onUpdateBegin(false);                 // створити завдання FFT, та ініціалізувати мережу


#ifdef ARDUINO_ARCH_ESP32
      if (FFT_Task == nullptr) enabled = false;          // створення завдання FFT не вдалося
      if((!audioSource) || (!audioSource->isInitialized())) {  // джерело аудіо не вдалося ініціалізувати. Залишаємось "enabled", оскільки може бути вхід через UDP Sound Sync 
      #ifdef WLED_DEBUG
        DEBUG_PRINTLN(F("AR: Не вдалося ініціалізувати драйвер вводу звуку. Перевірте налаштування PIN."));
      #else
        DEBUGSR_PRINTLN(F("AR: Не вдалося ініціалізувати драйвер вводу звуку. Перевірте налаштування PIN."));
      #endif
        disableSoundProcessing = true;
      }
#endif
      if (enabled) disableSoundProcessing = false;        // все добре - увімкнути обробку звуку
      if (enabled) connectUDPSoundSync();
      if (enabled && addPalettes) createAudioPalettes();
      initDone = true;
    }


    /*
     * connected() викликається кожного разу, коли WiFi (пере)підключається
     * Використовуйте це для ініціалізації мережевих інтерфейсів
     */
    void connected() override
    {
      if (udpSyncConnected) {   // очищення: якщо відкрито, закрити старе з'єднання UDP sync
        udpSyncConnected = false;
        fftUdp.stop();
      }
      
      if (audioSyncPort > 0 && (audioSyncEnabled & 0x03)) {
      #ifdef ARDUINO_ARCH_ESP32
        udpSyncConnected = fftUdp.beginMulticast(IPAddress(239, 0, 0, 1), audioSyncPort);
      #else
        udpSyncConnected = fftUdp.beginMulticast(WiFi.localIP(), IPAddress(239, 0, 0, 1), audioSyncPort);
      #endif
      }
    }


    /*
     * loop() викликається безперервно. Тут ви можете перевіряти події, читати сенсори тощо.
     */
    void loop() override
    {
      static unsigned long lastUMRun = millis();

      if (!enabled) {
        disableSoundProcessing = true;   // тримати обробку призупиненою (завдання FFT)
        lastUMRun = millis();            // оновити відлік часу
        return;
      }
      // Ми не можемо чекати нескінченно перед обробкою аудіоданих
      if (strip.isUpdating() && (millis() - lastUMRun < 2)) return;   // бути чемним, але не занадто

      // призупинити локальну обробку звуку, коли активний "режим реального часу" (E131, UDP, ADALIGHT, ARTNET)
      if (  (realtimeOverride == REALTIME_OVERRIDE_NONE)  // будь ласка, додайте інші перевизначення тут, якщо потрібно
          &&( (realtimeMode == REALTIME_MODE_GENERIC)
            ||(realtimeMode == REALTIME_MODE_E131)
            ||(realtimeMode == REALTIME_MODE_UDP)
            ||(realtimeMode == REALTIME_MODE_ADALIGHT)
            ||(realtimeMode == REALTIME_MODE_ARTNET) ) )  // будь ласка, додайте інші режими тут, якщо потрібно
      {
        #if defined(ARDUINO_ARCH_ESP32) && defined(WLED_DEBUG)
        if ((disableSoundProcessing == false) && (audioSyncEnabled == 0)) {  // ми щойно перемкнулися на "disabled"
          DEBUG_PRINTLN(F("[AR userLoop]  режим реального часу активний - обробку звуку призупинено."));
          DEBUG_PRINTF_P(PSTR("               RealtimeMode = %d; RealtimeOverride = %d\n"), int(realtimeMode), int(realtimeOverride));
        }
        #endif
        disableSoundProcessing = true;
      } else {
        #if defined(ARDUINO_ARCH_ESP32) && defined(WLED_DEBUG)
        if ((disableSoundProcessing == true) && (audioSyncEnabled == 0) && audioSource && audioSource->isInitialized()) {    // ми щойно перемкнулися на "enabled"
          DEBUG_PRINTLN(F("[AR userLoop]  режим реального часу завершено - обробку звуку відновлено."));
          DEBUG_PRINTF_P(PSTR("               RealtimeMode = %d; RealtimeOverride = %d\n"), int(realtimeMode), int(realtimeOverride));
        }
        #endif
        if ((disableSoundProcessing == true) && (audioSyncEnabled == 0)) lastUMRun = millis();  // тільки що вийшли з "realtime mode" - оновити час
        disableSoundProcessing = false;
      }

      if (audioSyncEnabled & 0x02) disableSoundProcessing = true;   // переконатися, що все вимкнено, ЯКЩО в режимі Отримання аудіо
      if (audioSyncEnabled & 0x01) disableSoundProcessing = false;  // продовжувати аудіо, ЯКЩО ми в режимі Передачі аудіо
#ifdef ARDUINO_ARCH_ESP32
      if (!audioSource || !audioSource->isInitialized()) disableSoundProcessing = true;  // немає джерела аудіо


      // Запускати код семплювання ТІЛЬКИ ЯКЩО ми не в режимі Отримання або режимі реального часу
      if (!(audioSyncEnabled & 0x02) && !disableSoundProcessing) {
        if (soundAgc > AGC_NUM_PRESETS) soundAgc = 0; // переконатися, що пресет АРП дійсний

        unsigned long t_now = millis();       // запам'ятати поточний час
        int userloopDelay = int(t_now - lastUMRun);
        if (lastUMRun == 0) userloopDelay=0; // запуск - немає дійсних даних з останнього прогону.

        #ifdef WLED_DEBUG
          // скаржитися, коли аудіо userloop затримується на довгий час.
          // softhack007 тимчасово вимкнено - уникати спаму в serial з БАГАТЬМА світлодіодами і низьким FPS
          //if ((userloopDelay > 65) && !disableSoundProcessing && (audioSyncEnabled == 0)) {
          //  DEBUG_PRINTF_P(PSTR("[AR userLoop] виявлено гикавку -> був неактивним останні %d мілісекунд!\n"), userloopDelay);
          //}
        #endif

        // запустити фільтри, і повторити у випадку затримок циклу (компенсація гикавки)
        if (userloopDelay <2) userloopDelay = 0;       // незначний збій, не проблема
        if (userloopDelay >200) userloopDelay = 200;   // обмежити кількість повторних запусків фільтра  
        do {
          getSample();                          // запустити фільтри семплювання мікрофона
          agcAvg(t_now - userloopDelay);        // Розрахувати скориговане PI значення як sampleAvg
          userloopDelay -= 2;                   // просунути "симульований час" на 2мс
        } while (userloopDelay > 0);
        lastUMRun = t_now;                    // оновити час

        // оновити семпли для ефектів (сирі, згладжені) 
        volumeSmth = (soundAgc) ? sampleAgc    : sampleAvg;
        volumeRaw  = (soundAgc) ? rawSampleAgc : sampleRaw;
        // оновити FFTMagnitude, враховуючи підсилення АРП
        my_magnitude = FFT_Magnitude; 
        if (soundAgc) my_magnitude *= multAgc;
        if (volumeSmth < 1 ) my_magnitude = 0.001f;  // шумоподавлювач закритий - тиша

        limitSampleDynamics();
      }  // if (!disableSoundProcessing)
#endif

      autoResetPeak();           // автоскидання піку семплу після мінімальної затримки відображення стрічки
      if (!udpSyncConnected) udpSamplePeak = false;  // скинути UDP samplePeak поки UDP не підключено

      connectUDPSoundSync();  // переконатися, що у нас є з'єднання - якщо потрібно

      // UDP Microphone Sync  - режим отримання
      if ((audioSyncEnabled & 0x02) && udpSyncConnected) {
          // Запускати код слухача аудіо тільки якщо ми в режимі Отримання
          static float syncVolumeSmth = 0;
          bool have_new_sample = false;
          if (millis() - lastTime > delayMs) {
            have_new_sample = receiveAudioData();
            if (have_new_sample) last_UDPTime = millis();
#ifdef ARDUINO_ARCH_ESP32
            else fftUdp.flush(); // Очистити вхідні буфери udp, якщо ми не читали - уникає гикавки в режимі отримання. Не працює на 8266.
#endif
            lastTime = millis();
          }
          if (have_new_sample) syncVolumeSmth = volumeSmth;   // запам'ятати отриманий семпл
          else volumeSmth = syncVolumeSmth;                   // відновити оригінально отриманий семпл для наступного запуску лімітера динаміки
          limitSampleDynamics();                              // запустити лімітер динаміки на отриманому volumeSmth, щоб приховати стрибки та гикавку
      }

      #if defined(MIC_LOGGER) || defined(MIC_SAMPLING_LOG) || defined(FFT_SAMPLING_LOG)
      static unsigned long lastMicLoggerTime = 0;
      if (millis()-lastMicLoggerTime > 20) {
        lastMicLoggerTime = millis();
        logAudio();
      }
      #endif

      // Info Page: зберігати макс семпл за останні 5 секунд
#ifdef ARDUINO_ARCH_ESP32
      if ((millis() -  sampleMaxTimer) > CYCLE_SAMPLEMAX) {
        sampleMaxTimer = millis();
        maxSample5sec = (0.15f * maxSample5sec) + 0.85f *((soundAgc) ? sampleAgc : sampleAvg); // скинути, і почати з деяким згладжуванням
        if (sampleAvg < 1) maxSample5sec = 0; // шумоподавлювач 
      } else {
         if ((sampleAvg >= 1)) maxSample5sec = fmaxf(maxSample5sec, (soundAgc) ? rawSampleAgc : sampleRaw); // слідувати за максимальною гучністю
      }
#else  // подібний функціонал для 8266 only receive - використовувати VolumeSmth замість сирих даних семплу
      if ((millis() -  sampleMaxTimer) > CYCLE_SAMPLEMAX) {
        sampleMaxTimer = millis();
        maxSample5sec = (0.15 * maxSample5sec) + 0.85 * volumeSmth; // скинути, і почати з деяким згладжуванням
        if (volumeSmth < 1.0f) maxSample5sec = 0; // шумоподавлювач
        if (maxSample5sec < 0.0f) maxSample5sec = 0; // уникати негативних значень
      } else {
         if (volumeSmth >= 1.0f) maxSample5sec = fmaxf(maxSample5sec, volumeRaw); // слідувати за максимальною гучністю
      }
#endif

#ifdef ARDUINO_ARCH_ESP32
      //UDP Microphone Sync  - режим передачі
      if ((audioSyncEnabled & 0x01) && (millis() - lastTime > 20)) {
        // Запускати код передачі ТІЛЬКИ ЯКЩО ми в режимі Передачі
        transmitAudioData();
        lastTime = millis();
      }
#endif

      fillAudioPalettes();
    }


    bool getUMData(um_data_t **data) override
    {
      if (!data || !enabled) return false; // вказівник не надано викликаючим або не увімкнено -> вихід
      *data = um_data;
      return true;
    }





    #ifdef ARDUINO_ARCH_ESP32
    void onUpdateBegin(bool init) override
    {
#ifdef WLED_DEBUG
      fftTime = sampleTime = 0;
#endif
      // граціозно призупинити завдання FFT (якщо працює)
      disableSoundProcessing = true;

      // скинути дані звуку
      micDataReal = 0.0f;
      volumeRaw = 0; volumeSmth = 0;
      sampleAgc = 0; sampleAvg = 0;
      sampleRaw = 0; rawSampleAgc = 0;
      my_magnitude = 0; FFT_Magnitude = 0; FFT_MajorPeak = 1;
      multAgc = 1;
      // скинути дані FFT
      memset(fftCalc, 0, sizeof(fftCalc)); 
      memset(fftAvg, 0, sizeof(fftAvg)); 
      memset(fftResult, 0, sizeof(fftResult)); 
      for(int i=(init?0:1); i<NUM_GEQ_CHANNELS; i+=2) fftResult[i] = 16; // зробити крихітний візерунок
      inputLevel = 128;                                          // скинути повзунок рівня за замовчуванням
      autoResetPeak();

      if (init && FFT_Task) {
        delay(25);                // дати трохи часу драйверу I2S завершити семплювання перед тим, як ми його призупинимо
        vTaskSuspend(FFT_Task);   // оновлення ось-ось почнеться, вимкнути завдання, щоб запобігти краху
        if (udpSyncConnected) {   // закрити з'єднання UDP sync (якщо відкрито)
          udpSyncConnected = false;
          fftUdp.stop();
        }
      } else {
        // оновлення не вдалося або запитано створення завдання
        if (FFT_Task) {
          vTaskResume(FFT_Task);
          connected(); // відновити UDP
        } else
          xTaskCreateUniversal(               // xTaskCreateUniversal також працює на -S2 та -C3 з одним ядром
            FFTcode,                          // Функція для реалізації завдання
            "FFT",                            // Ім'я завдання
            3592,                             // Розмір стеку в словах // 3592 залишає 800-1024 байт вільного стеку завдання
            NULL,                             // Вхідний параметр завдання
            FFTTASK_PRIORITY,                 // Пріоритет завдання
            &FFT_Task                         // Handle завдання
            , 0                               // Ядро, де має виконуватися завдання
          );
      }
      micDataReal = 0.0f;                     // просто щоб бути впевненим
      if (enabled) disableSoundProcessing = false;
      updateIsRunning = init;
    }

#else // скорочена функція для 8266
    void onUpdateBegin(bool init)
    {
      // граціозно призупинити аудіо (якщо працює)
      disableSoundProcessing = true;
      // скинути дані звуку
      volumeRaw = 0; volumeSmth = 0;
      for(int i=(init?0:1); i<NUM_GEQ_CHANNELS; i+=2) fftResult[i] = 16; // зробити крихітний візерунок
      autoResetPeak();
      if (init) {
        if (udpSyncConnected) {   // закрити з'єднання UDP sync (якщо відкрито)
          udpSyncConnected = false;
          fftUdp.stop();
          DEBUGSR_PRINTLN(F("AR onUpdateBegin(true): UDP connection closed."));
          receivedFormat = 0;
        }
      }
      if (enabled) disableSoundProcessing = init; // init = true означає, що OTA тільки починається --> не обробляти аудіо
      updateIsRunning = init;
    }
#endif

#ifdef ARDUINO_ARCH_ESP32
    /**
     * handleButton() може бути використано для перевизначення поведінки кнопки за замовчуванням.
     */
    bool handleButton(uint8_t b) override {
      yield();
      // грубий спосіб визначення, чи є аудіовхід аналоговим
      if (enabled
          && dmType == 0 && audioPin>=0
          && (buttons[b].type == BTN_TYPE_ANALOG || buttons[b].type == BTN_TYPE_ANALOG_INVERTED)
         ) {
        return true;
      }
      return false;
    }

#endif
    ////////////////////////////
    // Сторінка Налаштувань та Інфо //
    ////////////////////////////

    /*
     * addToJsonInfo() додає кастомні записи до /json/info
     */
/*
     * addToJsonInfo() додає кастомні записи до /json/info
     * ПЕРЕКЛАДЕНО УКРАЇНСЬКОЮ
     */
    void addToJsonInfo(JsonObject& root) override
    {
#ifdef ARDUINO_ARCH_ESP32
      char myStringBuffer[16]; // буфер для snprintf()
#endif
      JsonObject user = root["u"];
      if (user.isNull()) user = root.createNestedObject("u");

      // ТУТ ЗМІНЕНО: Заголовок секції в Інфо (відображається користувачу)
      JsonArray infoArr = user.createNestedArray("Світло музика");

      // Формування кнопки. Тут залишаємо _name, бо це внутрішня команда API
      String uiDomString = F("<button class=\"btn btn-xs\" onclick=\"requestJson({");
      uiDomString += FPSTR(_name); 
      uiDomString += F(":{");
      uiDomString += FPSTR(_enabled);
      uiDomString += enabled ? F(":false}});\">") : F(":true}});\">");
      uiDomString += F("<i class=\"icons");
      uiDomString += enabled ? F(" on") : F(" off");
      uiDomString += F("\">&#xe08f;</i>");
      uiDomString += F("</button>");
      infoArr.add(uiDomString);

      if (enabled) {
#ifdef ARDUINO_ARCH_ESP32
        // Повзунок рівня вхідного сигналу
        if (disableSoundProcessing == false) {                                // показувати повзунок тільки коли обробка аудіо працює
          if (soundAgc > 0) {
            infoArr = user.createNestedArray(F("Чутливість"));            // ПЕРЕКЛАДЕНО
          } else {
            infoArr = user.createNestedArray(F("Чутливість"));          // ПЕРЕКЛАДЕНО
          }
          uiDomString = F("<div class=\"slider\"><div class=\"sliderwrap il\"><input class=\"noslide\" onchange=\"requestJson({");
          uiDomString += FPSTR(_name);
          uiDomString += F(":{");
          uiDomString += FPSTR(_inputLvl);
          uiDomString += F(":parseInt(this.value)}});\" oninput=\"updateTrail(this);\" max=255 min=0 type=\"range\" value=");
          uiDomString += inputLevel;
          uiDomString += F(" /><div class=\"sliderdisplay\"></div></div></div>"); 
          infoArr.add(uiDomString);
        } 
#endif
        /* <-- Початок коментаря, щоб приховати технічні дані
        // поточний Audio вхід
        infoArr = user.createNestedArray(F("Джерело звуку")); // ПЕРЕКЛАДЕНО
        if (audioSyncEnabled & 0x02) {
          // UDP sound sync - режим отримання
          infoArr.add(F("Синхр. звуку UDP")); // ПЕРЕКЛАДЕНО
          if (udpSyncConnected) {
            if (millis() - last_UDPTime < 2500)
              infoArr.add(F(" - отримання")); // ПЕРЕКЛАДЕНО
            else
              infoArr.add(F(" - очікування")); // ПЕРЕКЛАДЕНО
          } else {
            infoArr.add(F(" - немає з'єднання")); // ПЕРЕКЛАДЕНО
          }
#ifndef ARDUINO_ARCH_ESP32  // заміна для 8266
        } else {
          infoArr.add(F("Синхр. вимкнено")); // ПЕРЕКЛАДЕНО
        }
#else  // ESP32 only
        } else {
          // Аналоговий або I2S цифровий вхід
          if (audioSource && (audioSource->isInitialized())) {
            // джерело аудіо успішно налаштовано
            if (audioSource->getType() == AudioSource::Type_I2SAdc) {
              infoArr.add(F("")); // ПЕРЕКЛАДЕНО ADC аналог
            } else {
              infoArr.add(F("")); // ПЕРЕКЛАДЕНО I2S цифра
            }
            // вхідний рівень або "тиша"
            if (maxSample5sec > 1.0f) {
              float my_usage = 100.0f * (maxSample5sec / 255.0f);
              snprintf_P(myStringBuffer, 15, PSTR("пік %3d%%"), int(my_usage)); // ПЕРЕКЛАДЕНО
              infoArr.add(myStringBuffer);
            } else {
              infoArr.add(F("тихо")); // ПЕРЕКЛАДЕНО
            }
          } else {
            // помилка під час налаштування аудіоджерела
            infoArr.add(F("не ініціалізовано")); // ПЕРЕКЛАДЕНО
            infoArr.add(F(" - перевір піни")); // ПЕРЕКЛАДЕНО
          }
        }

        // Обробка звуку (FFT та вхідні фільтри)
        infoArr = user.createNestedArray(F("Обробка звуку")); // ПЕРЕКЛАДЕНО
        if (audioSource && (disableSoundProcessing == false)) {
          infoArr.add(F("працює")); // ПЕРЕКЛАДЕНО
        } else {
          infoArr.add(F("призупинено")); // ПЕРЕКЛАДЕНО
        }

        // АРП або ручне Підсилення
        if ((soundAgc==0) && (disableSoundProcessing == false) && !(audioSyncEnabled & 0x02)) {
          infoArr = user.createNestedArray(F("Ручне підсилення")); // ПЕРЕКЛАДЕНО
          float myGain = ((float)sampleGain/40.0f * (float)inputLevel/128.0f) + 1.0f/16.0f;      // не-АРП підсилення з пресетів
          infoArr.add(roundf(myGain*100.0f) / 100.0f);
          infoArr.add("x");
        }
        if (soundAgc && (disableSoundProcessing == false) && !(audioSyncEnabled & 0x02)) {
          infoArr = user.createNestedArray(F("АРП підсилення")); // ПЕРЕКЛАДЕНО
          infoArr.add(roundf(multAgc*100.0f) / 100.0f);
          infoArr.add("x");
        }
#endif
        // Статус UDP Sound Sync
        infoArr = user.createNestedArray(F("Синхр. звуку UDP")); // ПЕРЕКЛАДЕНО
        if (audioSyncEnabled) {
          if (audioSyncEnabled & 0x01) {
            infoArr.add(F("режим передачі")); // ПЕРЕКЛАДЕНО
            if ((udpSyncConnected) && (millis() - lastTime < 2500)) infoArr.add(F(" v2"));
          } else if (audioSyncEnabled & 0x02) {
              infoArr.add(F("режим прийому")); // ПЕРЕКЛАДЕНО
          }
        } else
          infoArr.add("вимк"); // ПЕРЕКЛАДЕНО
        if (audioSyncEnabled && !udpSyncConnected) infoArr.add(" <i>(не підключено)</i>"); // ПЕРЕКЛАДЕНО
        if (audioSyncEnabled && udpSyncConnected && (millis() - last_UDPTime < 2500)) {
            if (receivedFormat == 1) infoArr.add(F(" v1"));
            if (receivedFormat == 2) infoArr.add(F(" v2"));
        }

        #if defined(WLED_DEBUG) || defined(SR_DEBUG)
        #ifdef ARDUINO_ARCH_ESP32
        infoArr = user.createNestedArray(F("Час семплювання")); // ПЕРЕКЛАДЕНО
        infoArr.add(float(sampleTime)/100.0f);
        infoArr.add(" ms");

        infoArr = user.createNestedArray(F("Час FFT")); // ПЕРЕКЛАДЕНО
        infoArr.add(float(fftTime)/100.0f);
        if ((fftTime/100) >= FFT_MIN_CYCLE) 
          infoArr.add("<b style=\"color:red;\">! ms</b>");
        else if ((fftTime/80 + sampleTime/80) >= FFT_MIN_CYCLE) 
          infoArr.add("<b style=\"color:orange;\"> ms!</b>");
        else
          infoArr.add(" ms");

        DEBUGSR_PRINTF("AR Sampling time: %5.2f ms\n", float(sampleTime)/100.0f);
        DEBUGSR_PRINTF("AR FFT time      : %5.2f ms\n", float(fftTime)/100.0f);
        #endif
        #endif
        */ // <-- Кінець коментаря
      }
    }

    /*
     * addToJsonState() додає кастомні записи до /json/state
     */
    void addToJsonState(JsonObject& root) override
    {
      if (!initDone) return;  // запобігти краху при boot applyPreset()
      JsonObject usermod = root[FPSTR(_name)];
      if (usermod.isNull()) {
        usermod = root.createNestedObject(FPSTR(_name));
      }
      usermod["on"] = enabled;
    }


    /*
     * readFromJsonState() читає дані, надіслані клієнтами в /json/state
     */
    void readFromJsonState(JsonObject& root) override
    {
      if (!initDone) return;  // запобігти краху при boot applyPreset()
      bool prevEnabled = enabled;
      JsonObject usermod = root[FPSTR(_name)];
      if (!usermod.isNull()) {
        if (usermod[FPSTR(_enabled)].is<bool>()) {
          enabled = usermod[FPSTR(_enabled)].as<bool>();
          if (prevEnabled != enabled) onUpdateBegin(!enabled);
          if (addPalettes) {
            // додати/видалити кастомні/audioreactive палітри
            if (prevEnabled && !enabled) removeAudioPalettes();
            if (!prevEnabled && enabled) createAudioPalettes();
          }
        }
#ifdef ARDUINO_ARCH_ESP32
        if (usermod[FPSTR(_inputLvl)].is<int>()) {
          inputLevel = min(255,max(0,usermod[FPSTR(_inputLvl)].as<int>()));
        }
#endif
      }
      if (root.containsKey(F("rmcpal")) && root[F("rmcpal")].as<bool>()) {
        // обробка видалення кастомних палітр
        removeAudioPalettes();
      }
    }

    void onStateChange(uint8_t callMode) override {
      if (initDone && enabled && addPalettes && palettes==0 && customPalettes.size()<10) {
        // якщо палітри були видалені під час виклику JSON, додати їх знову
        createAudioPalettes();
      }
    }

    /*
     * addToConfig() додає кастомні налаштування до файлу cfg.json
     */
    void addToConfig(JsonObject& root) override
    {
      JsonObject top = root.createNestedObject(FPSTR(_name));
      top[FPSTR(_enabled)] = enabled;
      top[FPSTR(_addPalettes)] = addPalettes;

#ifdef ARDUINO_ARCH_ESP32
    #if !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3) && !defined(CONFIG_IDF_TARGET_ESP32S3)
      JsonObject amic = top.createNestedObject(FPSTR(_analogmic));
      amic["pin"] = audioPin;
    #endif

      JsonObject dmic = top.createNestedObject(FPSTR(_digitalmic));
      dmic["type"] = dmType;
      JsonArray pinArray = dmic.createNestedArray("pin");
      pinArray.add(i2ssdPin);
      pinArray.add(i2swsPin);
      pinArray.add(i2sckPin);
      pinArray.add(mclkPin);

      JsonObject cfg = top.createNestedObject(FPSTR(_config));
      cfg[F("squelch")] = soundSquelch;
      cfg[F("gain")] = sampleGain;
      cfg[F("AGC")] = soundAgc;

      JsonObject freqScale = top.createNestedObject(FPSTR(_frequency));
      freqScale[F("scale")] = FFTScalingMode;
#endif

      JsonObject dynLim = top.createNestedObject(FPSTR(_dynamics));
      dynLim[F("limiter")] = limiterOn;
      dynLim[F("rise")] = attackTime;
      dynLim[F("fall")] = decayTime;

      JsonObject sync = top.createNestedObject("sync");
      sync["port"] = audioSyncPort;
      sync["mode"] = audioSyncEnabled;
    }


    /*
     * readFromConfig() читає збережені налаштування
     */
    bool readFromConfig(JsonObject& root) override
    {
      JsonObject top = root[FPSTR(_name)];
      bool configComplete = !top.isNull();
      bool oldEnabled = enabled;
      bool oldAddPalettes = addPalettes;

      configComplete &= getJsonValue(top[FPSTR(_enabled)], enabled);
      configComplete &= getJsonValue(top[FPSTR(_addPalettes)], addPalettes);

#ifdef ARDUINO_ARCH_ESP32
    #if !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3) && !defined(CONFIG_IDF_TARGET_ESP32S3)
      configComplete &= getJsonValue(top[FPSTR(_analogmic)]["pin"], audioPin);
    #else
      audioPin = -1; // MCU не підтримує аналоговий мікрофон
    #endif

      configComplete &= getJsonValue(top[FPSTR(_digitalmic)]["type"],   dmType);
    #if  defined(CONFIG_IDF_TARGET_ESP32S2) || defined(CONFIG_IDF_TARGET_ESP32C3) || defined(CONFIG_IDF_TARGET_ESP32S3)
      if (dmType == 0) dmType = SR_DMTYPE;   // MCU не підтримує аналог
      #if defined(CONFIG_IDF_TARGET_ESP32S2) || defined(CONFIG_IDF_TARGET_ESP32C3)
      if (dmType == 5) dmType = SR_DMTYPE;   // MCU не підтримує PDM
      #endif
    #endif

      configComplete &= getJsonValue(top[FPSTR(_digitalmic)]["pin"][0], i2ssdPin);
      configComplete &= getJsonValue(top[FPSTR(_digitalmic)]["pin"][1], i2swsPin);
      configComplete &= getJsonValue(top[FPSTR(_digitalmic)]["pin"][2], i2sckPin);
      configComplete &= getJsonValue(top[FPSTR(_digitalmic)]["pin"][3], mclkPin);

      configComplete &= getJsonValue(top[FPSTR(_config)][F("squelch")], soundSquelch);
      configComplete &= getJsonValue(top[FPSTR(_config)][F("gain")],    sampleGain);
      configComplete &= getJsonValue(top[FPSTR(_config)][F("AGC")],     soundAgc);

      configComplete &= getJsonValue(top[FPSTR(_frequency)][F("scale")], FFTScalingMode);

      configComplete &= getJsonValue(top[FPSTR(_dynamics)][F("limiter")], limiterOn);
      configComplete &= getJsonValue(top[FPSTR(_dynamics)][F("rise")],  attackTime);
      configComplete &= getJsonValue(top[FPSTR(_dynamics)][F("fall")],  decayTime);
#endif
      configComplete &= getJsonValue(top["sync"]["port"], audioSyncPort);
      configComplete &= getJsonValue(top["sync"]["mode"], audioSyncEnabled);

      if (initDone) {
        // додати/видалити кастомні/audioreactive палітри
        if ((oldAddPalettes && !addPalettes) || (oldAddPalettes && !enabled)) removeAudioPalettes();
        if ((addPalettes && !oldAddPalettes && enabled) || (addPalettes && !oldEnabled && enabled)) createAudioPalettes();
      } // інакше setup() створить палітри
      return configComplete;
    }


    void appendConfigData(Print& uiScript) override
    {
      uiScript.print(F("ux='AudioReactive';"));         // ux = ярлик для Audioreactive
#ifdef ARDUINO_ARCH_ESP32
      uiScript.print(F("uxp=ux+':digitalmic:pin[]';")); // uxp = ярлик для AudioReactive:digitalmic:pin[]
      uiScript.print(F("dd=addDropdown(ux,'digitalmic:type');"));
    #if  !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3) && !defined(CONFIG_IDF_TARGET_ESP32S3)
      uiScript.print(F("addOption(dd,'Generic Analog',0);"));
    #endif
      uiScript.print(F("addOption(dd,'Generic I2S',1);"));
      uiScript.print(F("addOption(dd,'ES7243',2);"));
      uiScript.print(F("addOption(dd,'SPH0654',3);"));
      uiScript.print(F("addOption(dd,'Generic I2S with Mclk',4);"));
    #if  !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3)
      uiScript.print(F("addOption(dd,'Generic I2S PDM',5);"));
    #endif
    uiScript.print(F("addOption(dd,'ES8388',6);"));
     
      uiScript.print(F("dd=addDropdown(ux,'config:AGC');"));
      uiScript.print(F("addOption(dd,'Off',0);"));
      uiScript.print(F("addOption(dd,'Normal',1);"));
      uiScript.print(F("addOption(dd,'Vivid',2);"));
      uiScript.print(F("addOption(dd,'Lazy',3);"));

      uiScript.print(F("dd=addDropdown(ux,'dynamics:limiter');"));
      uiScript.print(F("addOption(dd,'Off',0);"));
      uiScript.print(F("addOption(dd,'On',1);"));
      uiScript.print(F("addInfo(ux+':dynamics:limiter',0,' On ');"));  // 0 це тип поля, 1 це саме поле
      uiScript.print(F("addInfo(ux+':dynamics:rise',1,'ms <i>(&#x266A; effects only)</i>');"));
      uiScript.print(F("addInfo(ux+':dynamics:fall',1,'ms <i>(&#x266A; effects only)</i>');"));

      uiScript.print(F("dd=addDropdown(ux,'frequency:scale');"));
      uiScript.print(F("addOption(dd,'None',0);"));
      uiScript.print(F("addOption(dd,'Linear (Amplitude)',2);"));
      uiScript.print(F("addOption(dd,'Square Root (Energy)',3);"));
      uiScript.print(F("addOption(dd,'Logarithmic (Loudness)',1);"));
#endif

      uiScript.print(F("dd=addDropdown(ux,'sync:mode');"));
      uiScript.print(F("addOption(dd,'Off',0);"));
#ifdef ARDUINO_ARCH_ESP32
      uiScript.print(F("addOption(dd,'Send',1);"));
#endif
      uiScript.print(F("addOption(dd,'Receive',2);"));
#ifdef ARDUINO_ARCH_ESP32
      uiScript.print(F("addInfo(ux+':digitalmic:type',1,'<i>requires reboot!</i>');"));  // 0 це тип поля, 1 це саме поле
      uiScript.print(F("addInfo(uxp,0,'<i>sd/data/dout</i>','I2S SD');"));
      uiScript.print(F("addInfo(uxp,1,'<i>ws/clk/lrck</i>','I2S WS');"));
      uiScript.print(F("addInfo(uxp,2,'<i>sck/bclk</i>','I2S SCK');"));
      #if !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3) && !defined(CONFIG_IDF_TARGET_ESP32S3)
        uiScript.print(F("addInfo(uxp,3,'<i>only use -1, 0, 1 or 3</i>','I2S MCLK');"));
      #else
        uiScript.print(F("addInfo(uxp,3,'<i>master clock</i>','I2S MCLK');"));
      #endif
#endif
    }


    /*
     * handleOverlayDraw() викликається безпосередньо перед кожним show()
     */
    //void handleOverlayDraw() override
    //{
      //strip.setPixelColor(0, RGBW32(0,0,0,0)) // встановити перший піксель чорним
    //}

    
    /*
     * getId() дозволяє опціонально надати вашому V2 usermod унікальний ID
     */
    uint16_t getId() override
    {
      return USERMOD_ID_AUDIOREACTIVE;
    }
};

void AudioReactive::removeAudioPalettes(void) {
  DEBUG_PRINTLN(F("Видалення аудіо палітр."));
  while (palettes>0) {
    customPalettes.pop_back();
    DEBUG_PRINTLN(palettes);
    palettes--;
  }
  DEBUG_PRINT(F("Загальна # палітр: ")); DEBUG_PRINTLN(customPalettes.size());
}

void AudioReactive::createAudioPalettes(void) {
  DEBUG_PRINT(F("Загальна # палітр: ")); DEBUG_PRINTLN(customPalettes.size());
  if (palettes) return;
  DEBUG_PRINTLN(F("Додавання аудіо палітр."));
  for (int i=0; i<MAX_PALETTES; i++)
    if (customPalettes.size() < WLED_MAX_CUSTOM_PALETTES) {
      customPalettes.push_back(CRGBPalette16(CRGB(BLACK)));
      palettes++;
      DEBUG_PRINTLN(palettes);
    } else break;
}

// кредит @netmindz ar palette, адаптовано для usermod @blazoncek
CRGB AudioReactive::getCRGBForBand(int x, int pal) {
  CRGB value;
  CHSV hsv;
  int b;
  switch (pal) {
    case 2:
      b = map(x, 0, 255, 0, NUM_GEQ_CHANNELS/2); // конвертувати позицію палітри в нижню половину смуги частот
      hsv = CHSV(fftResult[b], 255, x);
      hsv2rgb_rainbow(hsv, value);  // конвертувати в R,G,B
      break;
    case 1:
      b = map(x, 1, 255, 0, 10); // конвертувати позицію палітри в нижню половину смуги частот
      hsv = CHSV(fftResult[b], 255, map(fftResult[b], 0, 255, 30, 255));  // вибрати відтінок
      hsv2rgb_rainbow(hsv, value);  // конвертувати в R,G,B
      break;
    default:
      if (x == 1) {
        value = CRGB(fftResult[10]/2, fftResult[4]/2, fftResult[0]/2);
      } else if(x == 255) {
        value = CRGB(fftResult[10]/2, fftResult[0]/2, fftResult[4]/2);
      } else {
        value = CRGB(fftResult[0]/2, fftResult[4]/2, fftResult[10]/2);
      }
      break;
  }
  return value;
}

void AudioReactive::fillAudioPalettes() {
  if (!palettes) return;
  size_t lastCustPalette = customPalettes.size();
  if (int(lastCustPalette) >= palettes) lastCustPalette -= palettes;
  for (int pal=0; pal<palettes; pal++) {
    uint8_t tcp[16];  // Має бути в 4 рази більше, ніж використовується кольорів.
                      // 3 кольори = 12, 4 кольори = 16, тощо.

    tcp[0] = 0;  // якір першого кольору - повинен бути нулем
    tcp[1] = 0;
    tcp[2] = 0;
    tcp[3] = 0;
     
    CRGB rgb = getCRGBForBand(1, pal);
    tcp[4] = 1;  // якір першого кольору
    tcp[5] = rgb.r;
    tcp[6] = rgb.g;
    tcp[7] = rgb.b;
     
    rgb = getCRGBForBand(128, pal);
    tcp[8] = 128;
    tcp[9] = rgb.r;
    tcp[10] = rgb.g;
    tcp[11] = rgb.b;
     
    rgb = getCRGBForBand(255, pal);
    tcp[12] = 255;  // якір останнього кольору - повинен бути 255
    tcp[13] = rgb.r;
    tcp[14] = rgb.g;
    tcp[15] = rgb.b;

    customPalettes[lastCustPalette+pal].loadDynamicGradientPalette(tcp);
  }
}

// рядки для зменшення використання флеш-пам'яті (використовуються більше двох разів)
const char AudioReactive::_name[]       PROGMEM = "AudioReactive";
const char AudioReactive::_enabled[]    PROGMEM = "enabled";
const char AudioReactive::_config[]     PROGMEM = "config";
const char AudioReactive::_dynamics[]   PROGMEM = "dynamics";
const char AudioReactive::_frequency[]  PROGMEM = "frequency";
const char AudioReactive::_inputLvl[]   PROGMEM = "inputLevel";
#if defined(ARDUINO_ARCH_ESP32) && !defined(CONFIG_IDF_TARGET_ESP32S2) && !defined(CONFIG_IDF_TARGET_ESP32C3) && !defined(CONFIG_IDF_TARGET_ESP32S3)
const char AudioReactive::_analogmic[]  PROGMEM = "analogmic";
#endif
const char AudioReactive::_digitalmic[] PROGMEM = "digitalmic";
const char AudioReactive::_addPalettes[]       PROGMEM = "add-palettes";
const char AudioReactive::UDP_SYNC_HEADER[]    PROGMEM = "00002"; // нова версія заголовка sync, оскільки формат більше не сумісний з попередньою структурою
const char AudioReactive::UDP_SYNC_HEADER_v1[] PROGMEM = "00001"; // стара версія заголовка sync - потрібно додати функцію зворотної сумісності

static AudioReactive ar_module;
REGISTER_USERMOD(ar_module);